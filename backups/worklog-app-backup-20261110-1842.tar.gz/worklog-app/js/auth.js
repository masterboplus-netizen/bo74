
// --- МОДУЛЬ: Авторизация и PIN ---
const PIN_KEY = 'worklog_pin';
const PIN_LEN = 6;
let PIN_BUF = '';
window.DATA = null;

function setupPinPad() {
  $$('.pin-pad button').forEach(btn => {
    btn.addEventListener('click', () => onPinKey(btn.dataset.d));
  });
  document.addEventListener('keydown', (e) => {
    const _ps = $('#pin-screen');
    if (!_ps || _ps.classList.contains('hidden')) return;
    if (e.key >= '0' && e.key <= '9') onPinKey(e.key);
    else if (e.key === 'Backspace') onPinKey('del');
    else if (e.key === 'Escape') onPinKey('clear');
  });
}

async function onPinKey(key) {
  if (key === 'clear') PIN_BUF = '';
  else if (key === 'del') PIN_BUF = PIN_BUF.slice(0, -1);
  else { if (PIN_BUF.length >= PIN_LEN) return; PIN_BUF += key; }
  updatePinDisplay();
  if (PIN_BUF.length === PIN_LEN) await submitPin(PIN_BUF);
}

function updatePinDisplay() {
  const disp = $('#pin-display');
  if (!disp) return;
  disp.innerHTML = '';
  for (let i = 0; i < PIN_LEN; i++) {
    const dot = document.createElement('div');
    dot.className = 'dot' + (i < PIN_BUF.length ? ' filled' : '');
    disp.appendChild(dot);
  }
  const err = $('#pin-error');
  if (err) err.textContent = '';
}

async function tryUnlock(pin) {
  try {
    // ВМЕСТО расшифровки файла - загружаем из Supabase
    if (typeof loadDataFromSupabase === 'function') {
      const ok = await loadDataFromSupabase();
      if (ok) return true;
      else throw new Error('Ошибка загрузки из Supabase');
    }
    
    // Если функции нет - выбрасываем ошибку (отключаем старый файл)
    return false; // Если функции нет, просто возвращаем false
  } catch(e) {
    const errDiv = document.getElementById('debug-error');
    if (errDiv) errDiv.remove();
    const d = document.createElement('div');
    d.id = 'debug-error';
    d.style.cssText = 'position:fixed; bottom:10px; left:10px; right:10px; background:red; color:white; padding:15px; z-index:99999; font-size:14px; border-radius:8px;';
    d.textContent = 'ОШИБКА: ' + e.message;
    document.body.appendChild(d);
    return false;
  }
}

async function submitPin(pin) {
  const ok = await tryUnlock(pin);
  if (ok) {
    const l = document.getElementById('loading');
    if (l) l.remove();
    renderDashboard();
    showScreen('dashboard');
  } else {
    PIN_BUF = '';
    updatePinDisplay();
    const err = $('#pin-error');
    if (err) err.textContent = 'Неверный PIN';
  }
}

function lock() {
  DATA = null;
  PIN_BUF = '';
  if (typeof updatePinDisplay === 'function') updatePinDisplay();
  
  // Жёстко вызываем showSafe
  if (typeof showSafe === 'function') {
    showSafe();
  } else {
    // Резервный вариант, если safe.js не загрузился
    const screen = document.getElementById('scroll-pin-screen');
    if (screen) screen.style.display = 'flex';
    const dash = document.getElementById('dashboard');
    if (dash) dash.style.display = 'none';
    const tabs = document.querySelector('.tabs');
    if (tabs) tabs.style.display = 'none';
  }
}

function showScreen(name) {
  ['pin-screen', 'dashboard', 'loading'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    if (id === name) el.classList.remove('hidden');
    else el.classList.add('hidden');
  });
  const tabs = document.querySelector('.tabs');
  if (tabs) tabs.style.display = (name === 'dashboard') ? 'flex' : 'none';
}
