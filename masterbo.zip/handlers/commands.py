"""Команды Telegram-бота БО 7.7"""
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from db import get_connection
from modules.objects import create_object, get_all_objects, get_object_by_name, get_object
from modules.tasks import create_task, get_active_tasks, close_task, get_tasks_by_object
from modules.finance import add_expense, get_finance_summary
from modules.parser import parse_message, parse_amount
from modules.personal import add_personal_expense
from config import ADMIN_IDS
from handlers.onboarding import ask_role, role_menu_keyboard


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Старт: онбординг при первом входе, иначе — меню по роли."""
    user = update.effective_user

    # === DEEP LINK: /start photo_<id> — открыть конкретное фото ===
    if context.args and context.args[0].startswith("photo_"):
        try:
            photo_id = int(context.args[0].replace("photo_", ""))
            from db import get_connection
            conn = get_connection()
            c = conn.cursor()
            c.execute("SELECT file_id, stage, caption, taken_at, task_id, object_id FROM photos WHERE id = ?", (photo_id,))
            row = c.fetchone()
            conn.close()
            if row:
                stage_names = {'before': '📸 До', 'progress': '🔵 Процесс', 'after': '✅ После', 'document': '📄 Документ'}
                caption_parts = [stage_names.get(row['stage'], row['stage'] or '')]
                if row['taken_at']:
                    caption_parts.append(f"📅 {row['taken_at'][:16]}")
                if row['caption']:
                    caption_parts.append(row['caption'])
                caption = " · ".join([p for p in caption_parts if p])
                await update.message.reply_photo(
                    photo=row['file_id'],
                    caption=caption[:1024] if caption else None
                )
                return
            else:
                await update.message.reply_text("❌ Фото не найдено.")
                return
        except Exception as e:
            await update.message.reply_text(f"❌ Ошибка: {e}")
            return

    # === ГЛАВНЫЙ АДМИН — сразу меню, без онбординга ===
    from config import MAIN_ADMIN_TG_ID
    if user.id == MAIN_ADMIN_TG_ID:
        # Сохраняем юзера
        try:
            from modules.users import save_user, set_role, mark_onboarded
            save_user(user.id, user.first_name or "", user.username or "", role="admin")
            set_role(user.id, "admin")
            try:
                mark_onboarded(user.id)
            except Exception:
                pass
        except Exception as e:
            print(f"⚠️ admin save: {e}")

        await update.message.reply_text(
            f"👋 Привет, {user.first_name}!\n\n"
            f"Я *Бо 7.7* — твой помощник по стройке.\n"
            f"Ты вошёл как *админ*.",
            reply_markup=role_menu_keyboard("admin"),
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # === ОБЫЧНЫЕ ЮЗЕРЫ ===
    # Сохраняем/обновляем юзера
    try:
        from modules.users import save_user, get_user
        save_user(user.id, user.first_name or "", user.username or "")
    except Exception as e:
        print(f"⚠️ save_user: {e}")

    # Определяем роль и онбординг
    role = "guest"
    onboarded = False
    try:
        from modules.users import get_user, is_onboarded
        u = get_user(user.id)
        if u:
            role = (u.get("role") if isinstance(u, dict) else u[3]) or "guest"
        onboarded = is_onboarded(user.id)
    except Exception as e:
        print(f"⚠️ get_user: {e}")

    # Первый вход → онбординг
    if not onboarded:
        await ask_role(update, context)
        return

    # Иначе — меню по роли
    await update.message.reply_text(
        f"👋 Привет, {user.first_name}!\n\n"
        f"Я *Бо 7.7* — твой помощник по стройке.\n"
        f"Твоя роль: *{role}*",
        reply_markup=role_menu_keyboard(role),
        parse_mode=ParseMode.MARKDOWN,
    )




def _help_text() -> str:
    """Текст справки (общий для /help и кнопки Помощь)."""
    return (
        "📋 Бо 7.7 — команды и возможности\n\n"
        "🏗️ Объекты\n"
        "• /objects — список объектов кнопками\n"
        "• /add\\_object <название> — создать объект\n\n"
        "📋 Задачи\n"
        "• /tasks — активные задачи кнопками\n"
        "• /add <объект> <задача> — быстро добавить\n"
        "• /add — меню добавления\n"
        "• /done <id> — закрыть задачу\n\n"
        "💰 Финансы\n"
        "• /finance — общая сводка кнопками\n"
        "• /finance <объект> — по объекту\n"
        "• /add\\_expense <объект> <сумма> [категория]\n\n"
        "💸 Личные — через меню\n"
        "📊 Отчёты — через меню\n"
        "📊 KPI — мастер, объекты, красная зона\n"
        "👥 CRM — клиенты, сделки, активности\n\n"
        "📝 Свободный ввод:\n"
        "• «потратил 5000 на материалы Арбат»\n"
        "• «добавь в Арбат положить паркет»\n"
        "• «500» — спросит личный/объект\n\n"
        "⏰ Автоматика:\n"
        "• Дайджест 9:00 МСК\n"
        "• Опрос 18:00 МСК\n"
        "• Автобэкап 23:00 МСК"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(_help_text(), parse_mode=ParseMode.MARKDOWN)


async def add_object_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Использование: /add_object <название>")
        return
    name = ' '.join(context.args)
    object_id = create_object(name, user_id=update.effective_user.id)
    await update.message.reply_text(f"✅ Объект «{name}» создан. ID: {object_id}")


async def objects_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    objs = get_all_objects()
    if not objs:
        await update.message.reply_text("🏗️ Объектов пока нет")
        return
    await update.message.reply_text(
        f"🏗️ **Объекты ({len(objs)}):**\n\nНажми на объект:",
        reply_markup=objects_keyboard(),
        parse_mode=ParseMode.MARKDOWN
    )


async def add_task_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        # Без аргументов — открываем интерактивное меню добавления
        await update.message.reply_text(
            "➕ Что добавить?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏗️ Новый объект", callback_data="add_object")],
                [InlineKeyboardButton("📋 Новая задача", callback_data="add_task")],
                [InlineKeyboardButton("💰 Расход", callback_data="add_expense")],
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")],
            ])
        )
        return
    if len(context.args) < 2:
        await update.message.reply_text("❌ Использование: /add <объект> <задача>")
        return
    obj = get_object_by_name(context.args[0])
    if not obj:
        await update.message.reply_text(f"❌ Объект «{context.args[0]}» не найден")
        return
    title = ' '.join(context.args[1:])
    task_id = create_task(obj['id'], title)
    await update.message.reply_text(f"✅ Задача «{title}» добавлена в «{obj['name']}». ID: {task_id}")


def format_tasks_block(title: str, items: list, emoji: str = '📋') -> str:
    """Форматирует блок задач, сгруппированный по объектам."""
    if not items:
        return ''
    # Группируем по объекту
    by_obj = {}
    order = []
    for r in items:
        obj = r['object_name'] or 'Без объекта'
        if obj not in by_obj:
            by_obj[obj] = []
            order.append(obj)
        by_obj[obj].append(r)

    from datetime import datetime as _dt
    lines = [f'{emoji} {title}']
    for obj in order:
        lines.append(f'')
        lines.append(f'🏗️ {obj}')
        for r in by_obj[obj]:
            d = ''
            if r['deadline']:
                try:
                    d = ' — ' + _dt.strptime(r['deadline'], '%Y-%m-%d').strftime('%d.%m')
                except Exception:
                    pass
            lines.append(f'  ▸ {r["id"]}. {r["title"]}{d}')
    return '\n'.join(lines)

async def tasks_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Задачи по датам с кнопками — как в меню."""
    from datetime import datetime, date, timedelta
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        SELECT t.id, t.title, t.deadline, o.name as object_name
        FROM tasks t
        LEFT JOIN objects o ON t.object_id = o.id
        WHERE t.status IN ('open', 'in_progress')
        ORDER BY t.deadline IS NULL, t.deadline ASC
    """)
    rows = c.fetchall()
    conn.close()

    if not rows:
        await update.message.reply_text("Нет активных задач")
        return

    today = date.today()
    tomorrow = today + timedelta(days=1)

    today_tasks = [r for r in rows if r['deadline'] and datetime.strptime(r['deadline'], '%Y-%m-%d').date() == today]
    tomorrow_tasks = [r for r in rows if r['deadline'] and datetime.strptime(r['deadline'], '%Y-%m-%d').date() == tomorrow]
    later_tasks = sorted(
        [r for r in rows if r['deadline'] and datetime.strptime(r['deadline'], '%Y-%m-%d').date() > tomorrow],
        key=lambda x: x['deadline']
    )
    no_deadline = [r for r in rows if not r['deadline']]

    sections = []
    if today_tasks:
        sections.append(format_tasks_block(f"СЕГОДНЯ — {today.strftime('%d.%m.%Y')}", today_tasks, '🔥'))
    if tomorrow_tasks:
        sections.append(format_tasks_block(f"ЗАВТРА — {tomorrow.strftime('%d.%m.%Y')}", tomorrow_tasks, '📅'))
    if later_tasks:
        sections.append(format_tasks_block("ПОЗЖЕ", later_tasks, '🗓'))
    if no_deadline:
        sections.append(format_tasks_block("БЕЗ СРОКА", no_deadline, '📋'))

    text = "📋 ЗАДАЧИ\n\n" + "\n\n".join(sections)
    if len(text) > 4000:
        text = text[:3900] + "\n\n..."

    buttons = []
    task_order = today_tasks + tomorrow_tasks + later_tasks + no_deadline
    for i, r in enumerate(task_order[:20], start=1):
        buttons.append([InlineKeyboardButton(
            f"{i}. {r['title'][:40]}",
            callback_data=f"task_{r['id']}"
        )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")])

    await update.message.reply_text(
        text + "\n\nВыбери задачу:",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def done_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Использование: /done <id>")
        return
    try:
        task_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID должен быть числом")
        return

    # Получаем задачу до закрытия (нужен object_id)
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT id, object_id, title FROM tasks WHERE id = ?", (task_id,))
    row = c.fetchone()
    conn.close()

    if not row:
        await update.message.reply_text(f"❌ Задача #{task_id} не найдена")
        return

    close_task(task_id, user_id=update.effective_user.id)

    # Ставим флаг: ждём фото для этой задачи
    context.user_data['photo_for_task'] = {
        'task_id': task_id,
        'object_id': row['object_id'],
    }

    await update.message.reply_text(
        f"✅ Задача #{task_id} «{row['title']}» выполнена!\n\n"
        f"📸 Приложи фото результата — оно привяжется к задаче.\n"
        f"Или нажми «Пропустить».",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("⏭️ Пропустить", callback_data=f"skip_photo_{task_id}")]
        ])
    )


async def handle_skip_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка «Пропустить фото»."""
    query = update.callback_query
    await query.answer()
    data = query.data
    if not data.startswith("skip_photo_"):
        return
    context.user_data['photo_for_task'] = None
    await query.edit_message_text("✅ Ок, без фото.")


async def finance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Если объект не указан — общая сводка с кнопками
    if not context.args:
        await update.message.reply_text(
            format_finance_summary(),
            reply_markup=finance_keyboard()
        )
        return

    obj = get_object_by_name(' '.join(context.args))
    if not obj:
        await update.message.reply_text("❌ Объект не найден")
        return
    f = get_finance_summary(obj['id'])
    await update.message.reply_text(
        f"💰 **{obj['name']}**\n"
        f"Доход: {f['income']} ₽\n"
        f"Расход: {f['expense']} ₽\n"
        f"Баланс: {f['balance']} ₽",
        parse_mode=ParseMode.MARKDOWN
    )


async def add_expense_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("❌ Использование: /add_expense <объект> <сумма> [категория]")
        return
    obj = get_object_by_name(context.args[0])
    if not obj:
        await update.message.reply_text(f"❌ Объект «{context.args[0]}» не найден")
        return
    try:
        amount = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Сумма должна быть числом")
        return
    category = context.args[2] if len(context.args) > 2 else 'прочее'
    add_expense(obj['id'], amount, category)
    await update.message.reply_text(f"✅ Расход {amount} ₽ ({category}) добавлен в «{obj['name']}»")


async def personal_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /personal — личные расходы за месяц."""
    await update.message.reply_text(
        format_personal_summary('month'),
        reply_markup=personal_keyboard()
    )

# === CRM: КЛИЕНТЫ И СДЕЛКИ ===

async def clients_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Список клиентов."""
    from modules.crm import format_clients
    await update.message.reply_text(
        format_clients(),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Добавить клиента", callback_data="crm_client_add")],
            [InlineKeyboardButton("⬅️ Меню", callback_data="menu_back")],
        ])
    )


async def deals_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Список сделок."""
    from modules.crm import format_deals
    await update.message.reply_text(
        format_deals(),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Добавить сделку", callback_data="crm_deal_add")],
            [InlineKeyboardButton("⬅️ Меню", callback_data="menu_back")],
        ])
    )


async def handle_crm_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик callback'ов CRM."""
    query = update.callback_query
    await query.answer()
    data = query.data
    print(f"🔍 CRM-MENU: data={data!r}", flush=True)

    if data == "menu_crm":
        from modules.crm import get_clients, get_deals
        clients = get_clients()
        deals = get_deals()
        await query.edit_message_text(
            f"👥 CRM\n\n"
            f"Клиентов: {len(clients)}\n"
            f"Сделок: {len(deals)}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(f"👥 Клиенты ({len(clients)})", callback_data="crm_clients")],
                [InlineKeyboardButton(f"💼 Сделки ({len(deals)})", callback_data="crm_deals")],
                [InlineKeyboardButton("➕ Добавить клиента", callback_data="crm_client_add")],
                [InlineKeyboardButton("➕ Добавить сделку", callback_data="crm_deal_add")],
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")],
            ])
        )
        return

    if data == "crm_clients":
        from modules.crm import format_clients, get_clients
        clients = get_clients()
        buttons = []
        for c in clients[:25]:
            label = f"👤 {c['name'][:30]}"
            if c.get('phone'):
                label += f" · {c['phone'][:15]}"
            buttons.append([InlineKeyboardButton(label, callback_data=f"client_{c['id']}")])
        buttons.append([InlineKeyboardButton("➕ Добавить", callback_data="crm_client_add")])
        buttons.append([InlineKeyboardButton("⬅️ К CRM", callback_data="menu_crm")])
        await query.edit_message_text(
            format_clients(),
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if data == "crm_deals":
        from modules.crm import format_deals, get_deals
        deals = get_deals()
        buttons = []
        st_icons = {"new": "🆕", "in_progress": "🔄", "won": "✅", "lost": "❌", "paused": "⏸"}
        for d in deals[:25]:
            icon = st_icons.get(d["status"], "•")
            cl = d["client_name"] or "—"
            label = f"{icon} #{d['id']} {cl[:25]} — {d['budget'] or 0} ₽"
            buttons.append([InlineKeyboardButton(label, callback_data=f"deal_{d['id']}")])
        buttons.append([InlineKeyboardButton("➕ Добавить", callback_data="crm_deal_add")])
        buttons.append([InlineKeyboardButton("⬅️ К CRM", callback_data="menu_crm")])
        await query.edit_message_text(
            format_deals(),
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if data.startswith("activity_call_") or data.startswith("activity_meeting_") or data.startswith("activity_note_"):
        parts = data.split("_")
        atype = parts[1]
        client_id = int(parts[2])
        type_names = {"call": "📞 Звонок", "meeting": "🤝 Встреча", "note": "📝 Заметка"}
        context.user_data["activity_client_id"] = client_id
        context.user_data["activity_type"] = atype
        context.user_data["waiting_for"] = "activity_text"
        await query.edit_message_text(
            f"{type_names.get(atype, atype)}\n\nНапиши текст:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Отмена", callback_data=f"client_{client_id}")],
            ])
        )
        return

    if data.startswith("activity_plan_"):
        client_id = int(data.replace("activity_plan_", ""))
        context.user_data["activity_client_id"] = client_id
        context.user_data["activity_type"] = "call"
        context.user_data["waiting_for"] = "activity_plan_datetime"
        await query.edit_message_text(
            "📅 Запланировать звонок\n\nНапиши дату и время. Например:\n"
            "«завтра 15:00»\n«25.09 10:30»\n«пн 12:00»",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Отмена", callback_data=f"client_{client_id}")],
            ])
        )
        return

    if data.startswith("activity_list_"):
        from modules.crm import get_client, get_client_activities, format_activities
        client_id = int(data.replace("activity_list_", ""))
        cl = get_client(client_id)
        acts = get_client_activities(client_id)
        text = f"📋 АКТИВНОСТИ: {cl['name'] if cl else '—'}\n\n"
        text += format_activities(acts)
        await query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ К клиенту", callback_data=f"client_{client_id}")],
            ])
        )
        return

    if data.startswith("client_"):
        from modules.crm import get_client, get_client_deals
        client_id = int(data.replace("client_", ""))
        cl = get_client(client_id)
        if not cl:
            await query.edit_message_text("❌ Клиент не найден")
            return
        deals = get_client_deals(client_id)
        st_names = {"new": "🆕 Новая", "in_progress": "🔄 В работе", "won": "✅ Выиграна", "lost": "❌ Проиграна", "paused": "⏸ Пауза"}
        text = f"👤 КЛИЕНТ #{client_id}\n\n"
        text += f"Имя: {cl['name']}\n"
        if cl.get('phone'):
            text += f"📞 {cl['phone']}\n"
        if cl.get('email'):
            text += f"✉️ {cl['email']}\n"
        if cl.get('address'):
            text += f"📍 {cl['address']}\n"
        if cl.get('source'):
            text += f"🔗 {cl['source']}\n"
        text += f"\n💼 СДЕЛКИ ({len(deals)}):\n"
        if deals:
            for d in deals[:10]:
                text += f"  • #{d['id']} {st_names.get(d['status'], d['status'])} — {d['budget'] or 0} ₽\n"
        else:
            text += "  нет сделок\n"
        buttons = [
            [InlineKeyboardButton("➕ Новая сделка", callback_data=f"crm_deal_client_{client_id}")],
        ]
        phone = cl.get('phone') if cl.get('phone') else None
        if phone:
            # Нормализуем: убираем всё кроме цифр и +
            clean = ''.join(ch for ch in phone if ch.isdigit() or ch == '+')
            if clean and not clean.startswith('+'):
                # Русские номера: если начинается с 8 или 7 — добавим +
                if clean.startswith('8') and len(clean) == 11:
                    clean = '+7' + clean[1:]
                elif clean.startswith('7') and len(clean) == 11:
                    clean = '+' + clean
                else:
                    clean = '+' + clean
            if clean:
                buttons.append([InlineKeyboardButton(f"📞 Позвонить {phone}", url=f"tel:{clean}")])
        buttons.append([InlineKeyboardButton("📅 Запланировать звонок", callback_data=f"activity_plan_{client_id}")])
        buttons.append([InlineKeyboardButton("🤝 Встреча", callback_data=f"activity_meeting_{client_id}"),
                        InlineKeyboardButton("📝 Заметка", callback_data=f"activity_note_{client_id}")])
        buttons.append([InlineKeyboardButton("📋 Активности", callback_data=f"activity_list_{client_id}")])
        for d in deals[:5]:
            buttons.append([InlineKeyboardButton(f"💼 Сделка #{d['id']} — {d['budget'] or 0} ₽", callback_data=f"deal_{d['id']}")])
        buttons.append([InlineKeyboardButton("⬅️ К клиентам", callback_data="crm_clients")])
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons))
        return

    if data == "crm_client_add":
        context.user_data['waiting_for'] = 'crm_client_name'
        await query.edit_message_text(
            "👤 Новый клиент\n\nНапиши имя клиента:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Отмена", callback_data="menu_crm")],
            ])
        )
        return

    if data == "crm_deal_add":
        from modules.crm import get_clients
        clients = get_clients()
        context.user_data['waiting_for'] = 'crm_deal_pick_client'
        buttons = []
        for c in clients[:20]:
            buttons.append([InlineKeyboardButton(
                f"👤 {c['name'][:35]}",
                callback_data=f"crm_deal_client_{c['id']}"
            )])
        buttons.append([InlineKeyboardButton("➕ Новый клиент", callback_data="crm_deal_new_client")])
        buttons.append([InlineKeyboardButton("⬅️ К CRM", callback_data="menu_crm")])
        await query.edit_message_text(
            "💼 Новая сделка\n\nВыбери клиента из списка или напиши имя нового:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if data.startswith("deal_"):
        from modules.crm import get_client_deals, get_deals, get_client
        parts = data.replace("deal_", "").split("_")
        deal_id = int(parts[0])
        conn = get_connection()
        c = conn.cursor()
        c.execute("SELECT id, client_id, object_id, status, budget FROM crm_deals WHERE id = ?", (deal_id,))
        d = c.fetchone()
        conn.close()
        if not d:
            await query.edit_message_text("❌ Сделка не найдена")
            return
        st_names = {"new": "🆕 Новая", "in_progress": "🔄 В работе", "won": "✅ Выиграна", "lost": "❌ Проиграна", "paused": "⏸ Пауза"}
        cl = get_client(d["client_id"])
        cl_name = cl["name"] if cl else "—"
        obj_name = "—"
        if d["object_id"]:
            o = get_object(d["object_id"])
            obj_name = o["name"] if o else "—"
        text = f"💼 СДЕЛКА #{deal_id}\n\n"
        text += f"👤 Клиент: {cl_name}\n"
        text += f"🏗️ Объект: {obj_name}\n"
        text += f"💼 Бюджет: {d['budget'] or 0} ₽\n"
        text += f"📊 Статус: {st_names.get(d['status'], d['status'])}\n\n"
        text += "Сменить статус:"
        await query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 В работе", callback_data=f"deal_status_{deal_id}_in_progress")],
                [InlineKeyboardButton("✅ Выиграна", callback_data=f"deal_status_{deal_id}_won")],
                [InlineKeyboardButton("❌ Проиграна", callback_data=f"deal_status_{deal_id}_lost")],
                [InlineKeyboardButton("⏸ Пауза", callback_data=f"deal_status_{deal_id}_paused")],
                [InlineKeyboardButton("👤 К клиенту", callback_data=f"client_{d['client_id']}")],
                [InlineKeyboardButton("⬅️ К сделкам", callback_data="crm_deals")],
            ])
        )
        return

    if data.startswith("deal_status_"):
        from modules.crm import update_deal_status, get_client
        parts = data.replace("deal_status_", "").split("_", 1)
        deal_id = int(parts[0])
        new_status = parts[1]
        update_deal_status(deal_id, new_status)
        st_names = {"new": "🆕 Новая", "in_progress": "🔄 В работе", "won": "✅ Выиграна", "lost": "❌ Проиграна", "paused": "⏸ Пауза"}
        await query.edit_message_text(
            f"✅ Сделка #{deal_id} → {st_names.get(new_status, new_status)}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ К сделке", callback_data=f"deal_{deal_id}")],
                [InlineKeyboardButton("💼 К сделкам", callback_data="crm_deals")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    if data == "crm_deal_new_client":
        context.user_data['waiting_for'] = 'crm_deal_new_client_name'
        await query.edit_message_text(
            "👤 Новый клиент для сделки\n\nНапиши имя:"
        )
        return

    if data == "crm_new_client_for_deal":
        # Не создаём сразу — идём пошаговым диалогом (телефон → адрес → источник)
        name = context.user_data.get('crm_new_client_name') or ''
        context.user_data['crm_deal_pending'] = True  # после создания → сделка
        context.user_data['waiting_for'] = 'crm_client_phone'
        await query.edit_message_text(
            f"👤 Новый клиент «{name}»\n\n"
            f"📞 Телефон (или Пропустить):",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_phone")],
            ])
        )
        return

    if data.startswith("crm_deal_client_"):
        client_id = int(data.replace("crm_deal_client_", ""))
        context.user_data['crm_deal_client_id'] = client_id
        context.user_data['waiting_for'] = 'crm_deal_budget'
        from modules.crm import get_client
        c = get_client(client_id)
        await query.edit_message_text(
            f"💼 Сделка для «{c['name']}»\n\nНапиши сумму бюджета (₽):"
        )
        return

    # === ПРОПУСК ШАГОВ CRM ===
    if data.startswith("crm_phone_pick_"):
        phone = data.replace("crm_phone_pick_", "")
        from modules.phone_utils import get_country_label
        country = get_country_label(phone)
        context.user_data['crm_new_client_phone'] = phone
        context.user_data['waiting_for'] = 'crm_client_address'
        await query.edit_message_text(
            f"✅ Телефон: {phone}\n{country}\n\n📍 Теперь адрес (или Пропустить):",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✏️ Изменить телефон", callback_data="crm_phone_edit")],
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_address")],
            ])
        )
        return

    if data == "crm_phone_edit":
        context.user_data['waiting_for'] = 'crm_client_phone_edit'
        await query.edit_message_text(
            "✏️ Введи новый телефон:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Назад", callback_data="crm_phone_edit_back")],
            ])
        )
        return

    if data == "crm_phone_edit_back":
        context.user_data['waiting_for'] = 'crm_client_address'
        await query.edit_message_text(
            "📍 Напиши адрес:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✏️ Изменить телефон", callback_data="crm_phone_edit")],
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_address")],
            ])
        )
        return

    if data == "crm_skip_phone":
        context.user_data['waiting_for'] = 'crm_client_address'
        await query.edit_message_text(
            "📍 Теперь адрес (или Пропустить):",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_address")],
            ])
        )
        return

    if data == "crm_skip_address":
        context.user_data['waiting_for'] = 'crm_client_source'
        await query.edit_message_text(
            "🔗 Откуда узнал (Авито / знакомые / ...)? Или Пропустить:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_source")],
            ])
        )
        return

    if data == "crm_skip_source":
        # Финализируем без источника
        from modules.crm import add_client
        name = context.user_data.get('crm_new_client_name') or '—'
        phone = context.user_data.get('crm_new_client_phone') or None
        address = context.user_data.get('crm_new_client_address') or None
        client_id = add_client(name=name, phone=phone, address=address, source=None)
        for k in ['crm_new_client_name', 'crm_new_client_phone',
                  'crm_new_client_address', 'crm_new_client_source']:
            context.user_data[k] = None

        # Если создавали для сделки — продолжаем
        if context.user_data.get('crm_deal_pending'):
            context.user_data['crm_deal_pending'] = False
            context.user_data['crm_deal_client_id'] = client_id
            context.user_data['waiting_for'] = 'crm_deal_budget'
            await query.edit_message_text(
                f"✅ Клиент #{client_id} создан!\n\n"
                f"👤 {name}\n"
                f"📞 {phone or '—'}\n"
                f"📍 {address or '—'}\n\n"
                f"💼 Теперь сумма сделки (₽):"
            )
            return

        context.user_data['waiting_for'] = None
        await query.edit_message_text(
            f"✅ Клиент #{client_id} создан!\n\n"
            f"👤 {name}\n"
            f"📞 {phone or '—'}\n"
            f"📍 {address or '—'}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("👥 К клиентам", callback_data="crm_clients")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    # === УМНЫЙ FALLBACK: пользователь выбрал, что делать с текстом ===
    if data == "unknown_as_object":
        text = context.user_data.get('unknown_text', '').strip()
        if not text:
            await query.edit_message_text("❌ Текст потерялся.")
            return
        # Ищем похожие объекты через rapidfuzz (нечёткий поиск)
        from rapidfuzz import process as rf_process, fuzz as rf_fuzz
        all_objs = get_all_objects()
        text_lower = text.lower()
        exact_match = None
        similar = []
        # 1. Точное совпадение
        for o in all_objs:
            if (o.get('name') or '').lower() == text_lower:
                exact_match = o
                break
        # 2. Нечёткий поиск через rapidfuzz
        if not exact_match and all_objs:
            names = [o.get('name') or '' for o in all_objs]
            matches = rf_process.extract(text, names, scorer=rf_fuzz.WRatio, limit=8)
            # matches: [(name, score, index), ...]
            print(f"🔍 RAPIDFUZZ: text={text!r}, matches={matches}", flush=True)
            for name, score, idx in matches:
                if score >= 55:  # порог — 55 (достаточно нечётко)
                    similar.append((all_objs[idx], score))
            print(f"🔍 RAPIDFUZZ: similar={[(o['name'], s) for o, s in similar]}", flush=True)
        
        # Точное совпадение — открываем сразу
        if exact_match:
            context.user_data['unknown_text'] = None
            await query.edit_message_text(
                f"✅ *Объект уже есть!*\n\n"
                f"🏗️ {exact_match['name']} (ID: {exact_match['id']})",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🏗️ Открыть объект", callback_data=f"obj_{exact_match['id']}")],
                    [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
                ])
            )
            return
        
        # Похожие — предлагаем выбрать или создать
        if similar:
            buttons = []
            for o, score in similar[:8]:
                buttons.append([InlineKeyboardButton(
                    f"🏗️ {o['name']} ({int(score)}%)",
                    callback_data=f"obj_{o['id']}"
                )])
            buttons.append([InlineKeyboardButton(
                f"➕ Создать новый «{text}»",
                callback_data="unknown_object_create_confirmed"
            )])
            buttons.append([InlineKeyboardButton("❌ Отмена", callback_data="unknown_cancel")])
            context.user_data['unknown_object_pending_name'] = text
            await query.edit_message_text(
                f"🔍 *Похожие объекты:*\n\n"
                f"Нашёл {len(similar)} с похожим названием.\n"
                f"Выбери существующий или создай новый:",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(buttons)
            )
            return
        
        # Ничего не нашли — создаём сразу
        from modules.objects import create_object
        new_obj_id = create_object(text, user_id=update.effective_user.id)
        context.user_data['unknown_text'] = None
        obj = get_object(new_obj_id)
        await query.edit_message_text(
            f"✅ *Объект создан!*\n\n"
            f"🏗️ {obj['name']} (ID: {new_obj_id})",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏗️ К объекту", callback_data=f"obj_{new_obj_id}")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    # Подтверждение создания нового объекта (если были похожие)
    if data == "unknown_object_create_confirmed":
        name = context.user_data.get('unknown_object_pending_name', '')
        if not name:
            await query.edit_message_text("❌ Имя потерялось.")
            return
        from modules.objects import create_object
        new_obj_id = create_object(name, user_id=update.effective_user.id)
        context.user_data['unknown_object_pending_name'] = None
        context.user_data['unknown_text'] = None
        obj = get_object(new_obj_id)
        await query.edit_message_text(
            f"✅ *Объект создан!*\n\n"
            f"🏗️ {obj['name']} (ID: {new_obj_id})",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏗️ К объекту", callback_data=f"obj_{new_obj_id}")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    if data == "unknown_as_client":
        text = context.user_data.get('unknown_text', '')
        context.user_data['crm_new_client_name'] = text
        context.user_data['waiting_for'] = 'crm_client_phone'
        context.user_data['unknown_text'] = None
        await query.edit_message_text(
            f"👤 Имя: «{text}»\n\n"
            f"📞 Теперь телефон (или Пропустить):",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_phone")],
            ])
        )
        return

    if data == "unknown_as_task":
        text = context.user_data.get('unknown_text', '')
        context.user_data['pending_task_title'] = text
        context.user_data['unknown_text'] = None
        # Спрашиваем объект
        objs = get_all_objects()
        buttons = []
        for o in objs[:20]:
            buttons.append([InlineKeyboardButton(
                f"🏗️ {o['name']}",
                callback_data=f"unknown_task_obj_{o['id']}"
            )])
        buttons.append([InlineKeyboardButton("❌ Отмена", callback_data="unknown_cancel")])
        await query.edit_message_text(
            f"📋 Задача: «{text}»\n\nВыбери объект:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if data == "unknown_as_expense":
        text = context.user_data.get('unknown_text', '')
        from modules.parser import parse_amount
        amount = parse_amount(text)
        if not amount:
            await query.edit_message_text(
                "❌ В тексте нет суммы. Попробуй ещё раз.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")]
                ])
            )
            return
        context.user_data['ask_expense_amount'] = amount
        context.user_data['unknown_text'] = None
        objs = get_all_objects()
        buttons = []
        for o in objs[:20]:
            buttons.append([InlineKeyboardButton(
                f"🏗️ {o['name']}",
                callback_data=f"exp_type_object_{amount}"
            )])
        buttons.append([InlineKeyboardButton("❌ Отмена", callback_data="menu_back")])
        await query.edit_message_text(
            f"💰 Расход {amount} ₽. Выбери объект:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if data == "unknown_as_personal":
        text = context.user_data.get('unknown_text', '')
        from modules.parser import parse_amount
        amount = parse_amount(text)
        if not amount:
            await query.edit_message_text(
                "❌ В тексте нет суммы.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")]
                ])
            )
            return
        context.user_data['pending_personal_expense'] = amount
        context.user_data['waiting_for'] = 'personal_expense_category'
        context.user_data['unknown_text'] = None
        await query.edit_message_text(
            f"💸 Личный расход {amount} ₽\n\nКатегория?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🍔 Еда", callback_data=f"personal_cat_{amount}_еда")],
                [InlineKeyboardButton("🚕 Транспорт", callback_data=f"personal_cat_{amount}_транспорт")],
                [InlineKeyboardButton("🏠 Жильё", callback_data=f"personal_cat_{amount}_жильё")],
                [InlineKeyboardButton("📦 Прочее", callback_data=f"personal_cat_{amount}_прочее")],
                [InlineKeyboardButton("❌ Отмена", callback_data="menu_back")],
            ])
        )
        return

    if data == "unknown_cancel":
        context.user_data['unknown_text'] = None
        await query.edit_message_text("✅ Ок, отменил.")
        return

    if data.startswith("unknown_task_obj_"):
        obj_id = int(data.replace("unknown_task_obj_", ""))
        title = context.user_data.get('pending_task_title', '')
        if not title:
            await query.edit_message_text("❌ Текст потерялся.")
            return
        tid = create_task(obj_id, title)
        obj = get_object(obj_id)
        context.user_data['pending_task_title'] = None
        await query.edit_message_text(
            f"✅ Задача #{tid} «{title}» добавлена в «{obj['name']}»",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📋 К задачам", callback_data="menu_tasks")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return


async def _finalize_new_client(update, context):
    """Создаёт клиента из собранных данных."""
    from modules.crm import add_client
    name = context.user_data.get('crm_new_client_name') or '—'
    phone = context.user_data.get('crm_new_client_phone') or None
    address = context.user_data.get('crm_new_client_address') or None
    source = context.user_data.get('crm_new_client_source') or None
    client_id = add_client(name=name, phone=phone, address=address, source=source)

    # Очищаем данные клиента
    for k in ['crm_new_client_name', 'crm_new_client_phone',
              'crm_new_client_address', 'crm_new_client_source']:
        context.user_data[k] = None

    # Если создавали для сделки — продолжаем сделку
    if context.user_data.get('crm_deal_pending'):
        context.user_data['crm_deal_pending'] = False
        context.user_data['crm_deal_client_id'] = client_id
        context.user_data['waiting_for'] = 'crm_deal_budget'
        await update.message.reply_text(
            f"✅ Клиент #{client_id} создан!\n\n"
            f"👤 {name}\n"
            f"📞 {phone or '—'}\n"
            f"📍 {address or '—'}\n"
            f"🔗 {source or '—'}\n\n"
            f"💼 Теперь сумма сделки (₽):"
        )
        return

    # Обычный режим — показываем карточку
    context.user_data['waiting_for'] = None
    await update.message.reply_text(
        f"✅ Клиент #{client_id} создан!\n\n"
        f"👤 {name}\n"
        f"📞 {phone or '—'}\n"
        f"📍 {address or '—'}\n"
        f"🔗 {source or '—'}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("👥 К клиентам", callback_data="crm_clients")],
            [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
        ])
    )


# === ОБРАБОТКА КНОПОК ===

def objects_keyboard():
    objs = get_all_objects()
    # Сортировка: active сверху, остальные внизу
    priority = {'active': 0, 'paused': 1, 'waiting': 2, 'completed': 3, 'closed': 4}
    objs_sorted = sorted(objs, key=lambda o: priority.get(o['status'], 9))

    buttons = []
    for obj in objs_sorted:
        icon = "🟢" if obj['status'] == 'active' else "⚪"
        buttons.append([InlineKeyboardButton(
            f"{icon} {obj['name']}",
            callback_data=f"obj_{obj['id']}"
        )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")])
    return InlineKeyboardMarkup(buttons)


def object_detail_keyboard(object_id):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📦 Комнаты", callback_data=f"rooms_list_obj_{object_id}")],
        [InlineKeyboardButton("📋 Задачи объекта", callback_data=f"objtasks_{object_id}")],
        [InlineKeyboardButton("💰 Финансы", callback_data=f"objfin_{object_id}")],
        [InlineKeyboardButton("📸 Фото объекта", callback_data=f"objphotos_{object_id}")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="menu_objects")],
    ])


def main_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏗️ Объекты", callback_data="menu_objects")],
        [InlineKeyboardButton("📋 Задачи", callback_data="menu_tasks")],
        [InlineKeyboardButton("💰 Финансы", callback_data="menu_finance")],
        [InlineKeyboardButton("📊 Отчёты", callback_data="menu_reports")],
        [InlineKeyboardButton("📊 KPI", callback_data="menu_kpi")],
        [InlineKeyboardButton("💸 Личные", callback_data="menu_personal")],
        [InlineKeyboardButton("👥 CRM", callback_data="menu_crm")],
        [InlineKeyboardButton("🌐 Дашборд", callback_data="menu_dashboard")],
        [InlineKeyboardButton("➕ Добавить", callback_data="menu_add")],
        [InlineKeyboardButton("⚙️ Помощь", callback_data="menu_help")],
    ])


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "menu_back":
        await query.edit_message_text(
            "🏠 **Главное меню**",
            reply_markup=main_menu_keyboard(),
            parse_mode=ParseMode.MARKDOWN
        )
        return

    if data == "menu_objects":
        objs = get_all_objects()
        if not objs:
            await query.edit_message_text("🏗️ Объектов пока нет")
            return
        await query.edit_message_text(
            f"🏗️ **Объекты ({len(objs)}):**\n\nНажми на объект:",
            reply_markup=objects_keyboard(),
            parse_mode=ParseMode.MARKDOWN
        )
        return

    if data == "menu_tasks":
        from datetime import datetime, date, timedelta
        conn = get_connection()
        c = conn.cursor()
        c.execute("""
            SELECT t.id, t.title, t.deadline, o.name as object_name
            FROM tasks t
            LEFT JOIN objects o ON t.object_id = o.id
            WHERE t.status IN ('open', 'in_progress')
            ORDER BY t.deadline IS NULL, t.deadline ASC
        """)
        rows = c.fetchall()
        conn.close()

        if not rows:
            await query.edit_message_text("Нет активных задач")
            return

        today = date.today()
        tomorrow = today + timedelta(days=1)

        # Группируем по датам
        sections = []
        today_tasks = [r for r in rows if r['deadline'] and datetime.strptime(r['deadline'], '%Y-%m-%d').date() == today]
        tomorrow_tasks = [r for r in rows if r['deadline'] and datetime.strptime(r['deadline'], '%Y-%m-%d').date() == tomorrow]
        later_tasks = sorted(
            [r for r in rows if r['deadline'] and datetime.strptime(r['deadline'], '%Y-%m-%d').date() > tomorrow],
            key=lambda x: x['deadline']
        )
        no_deadline = [r for r in rows if not r['deadline']]

        if today_tasks:
            sections.append(format_tasks_block(f"СЕГОДНЯ — {today.strftime('%d.%m.%Y')}", today_tasks, '🔥'))
        if tomorrow_tasks:
            sections.append(format_tasks_block(f"ЗАВТРА — {tomorrow.strftime('%d.%m.%Y')}", tomorrow_tasks, '📅'))
        if later_tasks:
            sections.append(format_tasks_block("ПОЗЖЕ", later_tasks, '🗓'))
        if no_deadline:
            sections.append(format_tasks_block("БЕЗ СРОКА", no_deadline, '📋'))

        text = "📋 ЗАДАЧИ\n\n" + "\n\n".join(sections)
        if len(text) > 4000:
            text = text[:3900] + "\n\n..."

        # Кнопки задач (макс 20), по порядку важности
        buttons = []
        task_order = today_tasks + tomorrow_tasks + later_tasks + no_deadline
        for i, r in enumerate(task_order[:20], start=1):
            buttons.append([InlineKeyboardButton(
                f"{i}. {r['title'][:40]}",
                callback_data=f"task_{r['id']}"
            )])
        buttons.append([InlineKeyboardButton("👤 Мои задачи", callback_data="my_tasks"),
                        InlineKeyboardButton("👥 По исполнителям", callback_data="by_assignee")])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")])

        await query.edit_message_text(
            text + "\n\nВыбери задачу:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if data == "my_tasks":
        from modules.tasks import get_tasks_by_assignee
        user_id = update.effective_user.id
        my = get_tasks_by_assignee(user_id)
        if not my:
            await query.edit_message_text(
                "👤 У тебя нет назначенных задач.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Назад", callback_data="menu_tasks")],
                ])
            )
            return
        text = f"👤 МОИ ЗАДАЧИ ({len(my)}):\n\n"
        buttons = []
        for i, t in enumerate(my[:20], start=1):
            d = ''
            if t['deadline']:
                d = f" ({t['deadline'][:10]})"
            obj = t['object_name'] or 'без объекта'
            text += f"#{t['id']} {t['title']}{d} — {obj}\n"
            buttons.append([InlineKeyboardButton(f"{i}. {t['title'][:40]}", callback_data=f"task_{t['id']}")])
        buttons.append([InlineKeyboardButton("⬅️ К задачам", callback_data="menu_tasks")])
        try:
            await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons))
        except Exception as e:
            if 'not modified' not in str(e).lower():
                raise
        return
    if data == "by_assignee":
        from modules.users import get_all_users
        from modules.tasks import get_tasks_by_assignee
        users = get_all_users()
        users = [u for u in users if u.get('role') in ('master', 'prorab', 'designer', 'admin')]
        buttons = []
        for u in users:
            cnt = len(get_tasks_by_assignee(u['tg_id']))
            label = f"👤 {u.get('name', '—')[:30]} ({cnt})"
            buttons.append([InlineKeyboardButton(label, callback_data=f"byassignee_{u['tg_id']}")])
        buttons.append([InlineKeyboardButton("⬅️ К задачам", callback_data="menu_tasks")])
        try:
            await query.edit_message_text(
                "👥 Задачи по исполнителям:",
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except Exception as e:
            if 'not modified' not in str(e).lower():
                raise
        return

    if data.startswith("byassignee_"):
        from modules.tasks import get_tasks_by_assignee
        from modules.users import get_user
        tg_id = int(data.replace("byassignee_", ""))
        tasks = get_tasks_by_assignee(tg_id)
        u = get_user(tg_id)
        uname = u.get('name') if u else f'id{tg_id}'
        if not tasks:
            try:
                await query.edit_message_text(
                    f"👤 {uname}\n\nНет активных задач.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅️ Назад", callback_data="by_assignee")],
                    ])
                )
            except Exception as e:
                if 'not modified' not in str(e).lower():
                    raise
            return
        text = f"👤 {uname} — {len(tasks)} задач:\n\n"
        buttons = []
        for i, t in enumerate(tasks[:20], start=1):
            d = ''
            if t['deadline']:
                d = f" ({t['deadline'][:10]})"
            obj = t['object_name'] or 'без объекта'
            text += f"#{t['id']} {t['title']}{d} — {obj}\n"
            buttons.append([InlineKeyboardButton(f"{i}. {t['title'][:40]}", callback_data=f"task_{t['id']}")])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="by_assignee")])
        try:
            await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons))
        except Exception as e:
            if 'not modified' not in str(e).lower():
                raise
        return

    if data == "menu_kpi":
        await query.edit_message_text(
            "📊 KPI И АНАЛИТИКА\n\n"
            "Выбери отчёт:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("👤 KPI мастеров (30 дн.)", callback_data="kpi_masters")],
                [InlineKeyboardButton("🏗️ Здоровье объектов", callback_data="kpi_objects")],
                [InlineKeyboardButton("⚠️ Красная зона", callback_data="kpi_red")],
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")],
            ])
        )
        return

    if data == "kpi_masters":
        from modules.kpi import get_master_kpi, format_master_kpi
        masters = get_master_kpi(30)
        text = format_master_kpi(masters, 30)
        try:
            await query.edit_message_text(
                text,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ К KPI", callback_data="menu_kpi")],
                    [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
                ])
            )
        except Exception as e:
            if 'not modified' not in str(e).lower():
                raise
        return

    if data == "kpi_objects":
        from modules.kpi import get_object_health, format_object_health
        objects = get_object_health()
        text = format_object_health(objects)
        try:
            await query.edit_message_text(
                text,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ К KPI", callback_data="menu_kpi")],
                    [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
                ])
            )
        except Exception as e:
            if 'not modified' not in str(e).lower():
                raise
        return

    if data == "kpi_red":
        from modules.kpi import get_red_zone, format_red_zone
        items = get_red_zone()
        text = format_red_zone(items)
        try:
            await query.edit_message_text(
                text,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ К KPI", callback_data="menu_kpi")],
                    [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
                ])
            )
        except Exception as e:
            if 'not modified' not in str(e).lower():
                raise
        return

    if data == "menu_finance":
        await query.edit_message_text(
            format_finance_summary(),
            reply_markup=finance_keyboard()
        )
        return

    if data.startswith("finobj_"):
        object_id = int(data.split("_")[1])
        obj = get_object(object_id)
        if not obj:
            await query.edit_message_text("❌ Объект не найден")
            return
        f = get_finance_summary(object_id)
        await query.edit_message_text(
            f"💰 **{obj['name']}**\n\n"
            f"Доход: {format_money(f['income'])} ₽\n"
            f"Расход: {format_money(f['expense'])} ₽\n"
            f"Баланс: {format_money(f['balance'])} ₽",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ К финансам", callback_data="menu_finance")]
            ]),
            parse_mode=ParseMode.MARKDOWN
        )
        return

    if data == "menu_personal":
        await query.edit_message_text(
            format_personal_summary('month'),
            reply_markup=personal_keyboard()
        )
        return

    if data == "personal_today":
        await query.edit_message_text(
            format_personal_summary('today'),
            reply_markup=personal_keyboard()
        )
        return

    if data == "personal_week":
        await query.edit_message_text(
            format_personal_summary('week'),
            reply_markup=personal_keyboard()
        )
        return

    if data == "personal_month":
        await query.edit_message_text(
            format_personal_summary('month'),
            reply_markup=personal_keyboard()
        )
        return

    if data == "personal_all":
        await query.edit_message_text(
            format_personal_summary('all'),
            reply_markup=personal_keyboard()
        )
        return

    if data == "personal_add":
        context.user_data['waiting_for'] = 'personal_expense_text'
        await query.edit_message_text(
            "💸 Новый личный расход\n\nНапиши сумму и категорию. Например:\n"
            "«300 еда»\n«1500 инструмент»\n«200 такси»",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_personal")]
            ])
        )
        return

    # === ВЫБОР: ЛИЧНЫЙ ИЛИ ПО ОБЪЕКТУ ===
    if data.startswith("exp_type_personal_"):
        amount = int(data.replace("exp_type_personal_", ""))
        context.user_data['pending_personal_expense'] = amount
        context.user_data['waiting_for'] = 'personal_expense_category'
        await query.edit_message_text(
            f"💸 Личный расход {amount} ₽\n\nЗа что?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🍔 Еда", callback_data=f"personal_cat_{amount}_еда")],
                [InlineKeyboardButton("🚕 Транспорт", callback_data=f"personal_cat_{amount}_транспорт")],
                [InlineKeyboardButton("🏠 Жильё", callback_data=f"personal_cat_{amount}_жильё")],
                [InlineKeyboardButton("💊 Медицина", callback_data=f"personal_cat_{amount}_медицина")],
                [InlineKeyboardButton("👕 Одежда", callback_data=f"personal_cat_{amount}_одежда")],
                [InlineKeyboardButton("📱 Связь", callback_data=f"personal_cat_{amount}_связь")],
                [InlineKeyboardButton("📦 Прочее", callback_data=f"personal_cat_{amount}_прочее")],
                [InlineKeyboardButton("❌ Отмена", callback_data="menu_back")],
            ])
        )
        return

    if data.startswith("exp_type_object_"):
        amount = int(data.replace("exp_type_object_", ""))
        context.user_data['pending_object_expense_amount'] = amount
        await query.edit_message_text(
            f"🏗️ Расход {amount} ₽\n\nВыбери объект:",
            reply_markup=choose_object_for_expense_keyboard_amount(amount)
        )
        return

    if data.startswith("personal_cat_"):
        parts = data.replace("personal_cat_", "").split("_", 1)
        amount = int(parts[0])
        category = parts[1]
        add_personal_expense(amount, category)
        context.user_data['pending_personal_expense'] = None
        context.user_data['waiting_for'] = None
        await query.edit_message_text(
            f"✅ Личный расход {amount} ₽ ({category}) записан",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💸 К личным", callback_data="menu_personal")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    if data.startswith("objexp_obj_"):
        # objexp_obj_<amount>_<obj_id>
        parts = data.replace("objexp_obj_", "").split("_")
        amount = int(parts[0])
        obj_id = int(parts[1])
        obj = get_object(obj_id)
        context.user_data['pending_obj_expense'] = {'amount': amount, 'obj_id': obj_id, 'obj_name': obj['name']}
        await query.edit_message_text(
            f"💰 {amount} ₽ в «{obj['name']}»\n\nЗа что?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🧱 Материалы", callback_data=f"objexp_cat_{amount}_{obj_id}_материалы")],
                [InlineKeyboardButton("🔧 Инструмент", callback_data=f"objexp_cat_{amount}_{obj_id}_инструмент")],
                [InlineKeyboardButton("🚕 Транспорт", callback_data=f"objexp_cat_{amount}_{obj_id}_транспорт")],
                [InlineKeyboardButton("🍔 Еда", callback_data=f"objexp_cat_{amount}_{obj_id}_еда")],
                [InlineKeyboardButton("📦 Прочее", callback_data=f"objexp_cat_{amount}_{obj_id}_прочее")],
                [InlineKeyboardButton("❌ Отмена", callback_data="menu_back")],
            ])
        )
        return

    if data.startswith("objexp_cat_"):
        # objexp_cat_<amount>_<obj_id>_<category>
        parts = data.replace("objexp_cat_", "").split("_", 2)
        amount = int(parts[0])
        obj_id = int(parts[1])
        category = parts[2] if len(parts) > 2 else 'прочее'
        obj = get_object(obj_id)
        add_expense(obj_id, amount, category)
        context.user_data['pending_object_expense_amount'] = None
        await query.edit_message_text(
            f"✅ Расход {amount} ₽ ({category}) в «{obj['name']}»",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏗️ К объекту", callback_data=f"obj_{obj_id}")],
                [InlineKeyboardButton("💰 К финансам", callback_data="menu_finance")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    # === ОТЧЁТЫ ===
    if data == "menu_reports":
        await query.edit_message_text(
            "📊 ОТЧЁТЫ\n\nВыбери тип:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Что сделано (неделя)", callback_data="report_closed_week")],
                [InlineKeyboardButton("✅ Что сделано (месяц)", callback_data="report_closed_month")],
                [InlineKeyboardButton("🔄 Что в работе", callback_data="report_open")],
                [InlineKeyboardButton("📈 Финансы за месяц", callback_data="report_summary_month")],
                [InlineKeyboardButton("📈 Финансы за неделю", callback_data="report_summary_week")],
                [InlineKeyboardButton("📈 Финансы за всё время", callback_data="report_summary_all")],
                [InlineKeyboardButton("🏗️ Отчёт по объекту", callback_data="report_choose_object")],
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")],
            ])
        )
        return

    if data.startswith("report_summary_"):
        period = data.replace("report_summary_", "")
        from modules.reports import get_summary_report, format_summary_report
        report = get_summary_report(period)
        text = format_summary_report(report)
        await query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ К отчётам", callback_data="menu_reports")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    if data == "report_closed_week" or data == "report_closed_month":
        period = 'week' if data == "report_closed_week" else 'month'
        from modules.reports import get_closed_tasks_report, format_closed_tasks_report
        report = get_closed_tasks_report(period)
        text = format_closed_tasks_report(report)
        await query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ К отчётам", callback_data="menu_reports")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    if data == "report_open":
        from modules.reports import get_open_tasks_report, format_open_tasks_report
        report = get_open_tasks_report()
        text = format_open_tasks_report(report)
        await query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ К отчётам", callback_data="menu_reports")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    if data == "report_choose_object":
        objs = get_all_objects()
        buttons = []
        for o in objs:
            buttons.append([InlineKeyboardButton(
                f"🏗️ {o['name']}",
                callback_data=f"report_obj_{o['id']}_month"
            )])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_reports")])
        await query.edit_message_text(
            "📊 Выбери объект для отчёта (за месяц):",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if data.startswith("report_obj_"):
        # report_obj_<obj_id>_<period>
        parts = data.replace("report_obj_", "").split("_")
        obj_id = int(parts[0])
        period = parts[1] if len(parts) > 1 else 'month'
        from modules.reports import get_object_report, format_object_report
        report = get_object_report(obj_id, period)
        text = format_object_report(report)
        await query.edit_message_text(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📅 За неделю", callback_data=f"report_obj_{obj_id}_week")],
                [InlineKeyboardButton("📅 За месяц", callback_data=f"report_obj_{obj_id}_month")],
                [InlineKeyboardButton("📅 За всё время", callback_data=f"report_obj_{obj_id}_all")],
                [InlineKeyboardButton("📸 Фото объекта", callback_data=f"objphotos_{obj_id}")],
                [InlineKeyboardButton("⬅️ К отчётам", callback_data="menu_reports")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    if data == "menu_dashboard":
        from modules.dashboard_link import get_dashboard_url
        url = get_dashboard_url()
        await query.edit_message_text(
            f"🌐 Дашборд Бо 7.7\n\n"
            f"Нажми кнопку ниже, чтобы открыть:\n\n"
            f"📱 Совет: добавь на главный экран телефона",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🌐 Открыть дашборд", url=url)],
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")]
            ])
        )
        return

    if data == "menu_help":
        await query.edit_message_text(
            _help_text(),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")]
            ]),
            parse_mode=ParseMode.MARKDOWN
        )
        return

    if data.startswith("objtasks_"):
        object_id = int(data.split("_")[1])
        tasks = get_tasks_by_object(object_id)
        if not tasks:
            await query.edit_message_text("📋 Задач нет", reply_markup=object_detail_keyboard(object_id))
            return
        text = "📋 **Задачи объекта:**\n\n"
        for t in tasks[:20]:
            icon = "✅" if t['status'] == 'done' else "🔵"
            text += f"{icon} {t['id']}. {t['title']}\n"
        await query.edit_message_text(text, reply_markup=object_detail_keyboard(object_id), parse_mode=ParseMode.MARKDOWN)
        return

    if data.startswith("objfin_"):
        object_id = int(data.split("_")[1])
        f = get_finance_summary(object_id)
        await query.edit_message_text(
            f"💰 **Финансы**\n\nДоход: {f['income']} ₽\nРасход: {f['expense']} ₽\nБаланс: {f['balance']} ₽",
            reply_markup=object_detail_keyboard(object_id),
            parse_mode=ParseMode.MARKDOWN
        )
        return

    if data.startswith("objphotos_"):
        object_id = int(data.split("_")[1])
        obj = get_object(object_id)
        conn = get_connection()
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM photos WHERE object_id = ?", (object_id,))
        total = c.fetchone()[0] or 0
        conn.close()

        if total == 0:
            await query.edit_message_text(
                f"📸 Фото объекта «{obj['name']}»\n\nПока нет фото.\n\n"
                f"Отправь боту фото, чтобы добавить.",
                reply_markup=object_detail_keyboard(object_id)
            )
            return

        await query.edit_message_text(
            f"📸 *Фото «{obj['name']}»*\n"
            f"Всего: {total}\n\n"
            f"Выбери фильтр:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🆕 Последние (3 задачи)", callback_data=f"photofilt_last_{object_id}_0")],
                [InlineKeyboardButton("📋 По задачам", callback_data=f"photofilt_tasks_{object_id}")],
                [InlineKeyboardButton("📅 По датам", callback_data=f"photofilt_dates_{object_id}")],
                [InlineKeyboardButton("👤 Кто загрузил", callback_data=f"photofilt_uploaders_{object_id}")],
                [InlineKeyboardButton("🛠 Кто делал задачу", callback_data=f"photofilt_assignees_{object_id}")],
                [InlineKeyboardButton("⬅️ К объекту", callback_data=f"obj_{object_id}")],
            ]),
            parse_mode=ParseMode.MARKDOWN
        )
        return

    if data.startswith("obj_"):
        object_id = int(data.split("_")[1])
        obj = get_object(object_id)
        if not obj:
            await query.edit_message_text("❌ Объект не найден")
            return
        tasks = get_tasks_by_object(object_id)
        open_tasks = len([t for t in tasks if t['status'] == 'open'])
        f = get_finance_summary(object_id)
        text = (
            f"🏗️ **{obj['name']}**\n\n"
            f"**Статус:** {obj['status']}\n"
            f"**Бюджет:** {obj['budget']} ₽\n"
            f"**Задачи:** {open_tasks} открытых\n"
            f"**Доход:** {f['income']} ₽\n"
            f"**Расход:** {f['expense']} ₽\n"
            f"**Баланс:** {f['balance']} ₽"
        )
        await query.edit_message_text(text, reply_markup=object_detail_keyboard(object_id), parse_mode=ParseMode.MARKDOWN)
        return




async def photos_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/photos <объект> — все фото по объекту, с группировкой по этапам."""

    # Определяем объект
    if context.args:
        obj = get_object_by_name(' '.join(context.args))
        if not obj:
            await update.message.reply_text(
                f"❌ Объект «{' '.join(context.args)}» не найден"
            )
            return
    else:
        await update.message.reply_text(
            "❌ Использование: /photos <объект>\n"
            "Пример: /photos Переделкино"
        )
        return

    # Достаём фото
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        SELECT p.id, p.file_id, p.stage, p.caption, p.taken_at, p.created_at,
               p.task_id, t.title as task_title
        FROM photos p
        LEFT JOIN tasks t ON p.task_id = t.id
        WHERE p.object_id = ?
        ORDER BY p.stage, p.taken_at DESC
    """, (obj['id'],))
    rows = c.fetchall()
    conn.close()

    if not rows:
        await update.message.reply_text(
            f"📸 По объекту «{obj['name']}» фото нет.\n\n"
            f"Отправь фото боту, чтобы добавить."
        )
        return

    # Группируем по этапам
    stage_names = {
        'before': '📸 До',
        'progress': '🔵 Процесс',
        'after': '✅ После',
        'document': '📄 Документы',
    }
    by_stage = {}
    for r in rows:
        st = r['stage'] or 'progress'
        by_stage.setdefault(st, []).append(r)

    # Заголовок
    text = f"📸 Фото по объекту «{obj['name']}»\n"
    text += f"Всего: {len(rows)}\n\n"
    for st, items in by_stage.items():
        text += f"{stage_names.get(st, st)}: {len(items)}\n"

    await update.message.reply_text(text)

    # Отправляем фото (максимум 20)
    count = 0
    for st, items in by_stage.items():
        for r in items:
            if count >= 20:
                break
            caption_parts = [stage_names.get(st, st)]
            if r['task_title']:
                caption_parts.append(f"#{r['task_id']} {r['task_title'][:40]}")
            if r['caption']:
                caption_parts.append(r['caption'])
            if r['taken_at']:
                caption_parts.append(f"📅 {r['taken_at'][:10]}")
            caption = " · ".join(caption_parts)

            try:
                await update.message.reply_photo(
                    photo=r['file_id'],
                    caption=caption[:1024]
                )
                count += 1
            except Exception as e:
                # Если file_id устарел — сообщаем
                await update.message.reply_text(f"⚠️ Не смог отправить фото #{r['id']}: {e}")

        if count >= 20:
            break

    if len(rows) > 20:
        await update.message.reply_text(
            f"... (показаны первые 20 из {len(rows)})"
        )


# === ФИЛЬТРЫ ФОТО ===

async def _show_photos_batch(update, context, photos, page=0, header="📸 Фото"):
    """Показывает по 3 фото, с кнопкой 'Показать ещё'."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    BATCH = 3
    start = page * BATCH
    end = start + BATCH
    batch = photos[start:end]

    stage_names = {'before': '📸 До', 'progress': '🔵 Процесс', 'after': '✅ После', 'document': '📄 Документ'}
    for r in batch:
        caption_parts = [stage_names.get(r['stage'], r['stage'] or '')]
        if r.get('task_title'):
            caption_parts.append(f"#{r['task_id']} {r['task_title'][:40]}")
        if r.get('caption'):
            caption_parts.append(r['caption'])
        if r.get('taken_at'):
            caption_parts.append(f"📅 {r['taken_at'][:10]}")
        caption = " · ".join([p for p in caption_parts if p])
        try:
            await context.bot.send_photo(
                chat_id=update.effective_chat.id,
                photo=r['file_id'],
                caption=caption[:1024]
            )
        except Exception as e:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=f"⚠️ Не смог отправить фото #{r.get('id', '?')}: {e}"
            )

    # Кнопка «Показать ещё»
    buttons = []
    if end < len(photos):
        buttons.append([InlineKeyboardButton(
            f"⬇️ Показать ещё (осталось {len(photos) - end})",
            callback_data=f"photopage_{context.user_data.get('photo_filter_key', '')}_{page + 1}"
        )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=context.user_data.get('photo_back', 'menu_back'))])

    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=f"{header}\nПоказано {min(end, len(photos))} из {len(photos)}",
        reply_markup=InlineKeyboardMarkup(buttons) if buttons else None
    )


async def handle_photo_filter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик всех фильтров фото."""
    query = update.callback_query
    await query.answer()
    data = query.data

    # Формат: photofilt_<тип>_<obj_id>_<доп>
    parts = data.replace("photofilt_", "").split("_")
    ftype = parts[0]
    obj_id = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
    extra = parts[2] if len(parts) > 2 else None

    obj = get_object(obj_id) if obj_id else None
    obj_name = obj['name'] if obj else '—'

    conn = get_connection()
    c = conn.cursor()

    if ftype == "last":
        # Последние 3 задачи с фото
        c.execute("""
            SELECT DISTINCT p.task_id
            FROM photos p
            WHERE p.object_id = ? AND p.task_id IS NOT NULL
            ORDER BY p.taken_at DESC
            LIMIT 3
        """, (obj_id,))
        task_ids = [r[0] for r in c.fetchall()]
        if not task_ids:
            conn.close()
            await query.edit_message_text(
                f"📸 Последние фото «{obj_name}»\n\nЗадач с фото нет.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Назад", callback_data=f"objphotos_{obj_id}")]
                ])
            )
            return
        placeholders = ",".join("?" * len(task_ids))
        c.execute(f"""
            SELECT p.id, p.file_id, p.stage, p.caption, p.taken_at, p.task_id,
                   t.title as task_title
            FROM photos p
            LEFT JOIN tasks t ON p.task_id = t.id
            WHERE p.object_id = ? AND p.task_id IN ({placeholders})
            ORDER BY p.taken_at DESC
        """, [obj_id] + task_ids)
        photos = [dict(r) for r in c.fetchall()]
        conn.close()
        context.user_data['photo_filter_key'] = f"last_{obj_id}"
        context.user_data['photo_back'] = f"objphotos_{obj_id}"
        context.user_data['photo_cache'] = photos
        await query.edit_message_text(
            f"🆕 Последние фото «{obj_name}»\n({len(task_ids)} задач, {len(photos)} фото)"
        )
        await _show_photos_batch(update, context, photos, page=0, header=f"🆕 Последние фото «{obj_name}»")
        return

    if ftype == "tasks":
        c.execute("""
            SELECT t.id, t.title, COUNT(p.id) as cnt
            FROM tasks t
            JOIN photos p ON p.task_id = t.id
            WHERE p.object_id = ?
            GROUP BY t.id, t.title
            ORDER BY MAX(p.taken_at) DESC
        """, (obj_id,))
        rows = c.fetchall()
        conn.close()
        if not rows:
            await query.edit_message_text(
                f"📸 Задачи с фото «{obj_name}»\n\nПока нет.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Назад", callback_data=f"objphotos_{obj_id}")]
                ])
            )
            return
        buttons = []
        for r in rows[:25]:
            buttons.append([InlineKeyboardButton(
                f"#{r['id']} {r['title'][:35]} ({r['cnt']})",
                callback_data=f"photofilt_task_{obj_id}_{r['id']}"
            )])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"objphotos_{obj_id}")])
        await query.edit_message_text(
            f"📋 Задачи с фото «{obj_name}»\n\nВыбери задачу:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if ftype == "task":
        task_id = int(extra) if extra else 0
        c.execute("""
            SELECT p.id, p.file_id, p.stage, p.caption, p.taken_at, p.task_id,
                   t.title as task_title
            FROM photos p
            LEFT JOIN tasks t ON p.task_id = t.id
            WHERE p.object_id = ? AND p.task_id = ?
            ORDER BY p.taken_at DESC
        """, (obj_id, task_id))
        photos = [dict(r) for r in c.fetchall()]
        conn.close()
        context.user_data['photo_filter_key'] = f"task_{obj_id}_{task_id}"
        context.user_data['photo_back'] = f"photofilt_tasks_{obj_id}"
        context.user_data['photo_cache'] = photos
        title = photos[0]['task_title'] if photos else f"#{task_id}"
        await query.edit_message_text(f"📋 Фото задачи #{task_id} «{title}»\nВсего: {len(photos)}")
        await _show_photos_batch(update, context, photos, page=0, header=f"📋 Фото задачи #{task_id}")
        return

    if ftype == "dates":
        c.execute("""
            SELECT DATE(p.taken_at) as d, COUNT(*) as cnt
            FROM photos p
            WHERE p.object_id = ?
            GROUP BY DATE(p.taken_at)
            ORDER BY d DESC
        """, (obj_id,))
        rows = c.fetchall()
        conn.close()
        if not rows:
            await query.edit_message_text(
                f"📸 Даты с фото «{obj_name}»\n\nПока нет.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Назад", callback_data=f"objphotos_{obj_id}")]
                ])
            )
            return
        buttons = []
        for r in rows[:25]:
            buttons.append([InlineKeyboardButton(
                f"📅 {r['d']} ({r['cnt']})",
                callback_data=f"photofilt_date_{obj_id}_{r['d']}"
            )])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"objphotos_{obj_id}")])
        await query.edit_message_text(
            f"📅 Фото «{obj_name}» по датам:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if ftype == "date":
        date_str = extra or ''
        c.execute("""
            SELECT p.id, p.file_id, p.stage, p.caption, p.taken_at, p.task_id,
                   t.title as task_title
            FROM photos p
            LEFT JOIN tasks t ON p.task_id = t.id
            WHERE p.object_id = ? AND DATE(p.taken_at) = ?
            ORDER BY p.taken_at DESC
        """, (obj_id, date_str))
        photos = [dict(r) for r in c.fetchall()]
        conn.close()
        context.user_data['photo_filter_key'] = f"date_{obj_id}_{date_str}"
        context.user_data['photo_back'] = f"photofilt_dates_{obj_id}"
        context.user_data['photo_cache'] = photos
        await query.edit_message_text(f"📅 Фото за {date_str}\nВсего: {len(photos)}")
        await _show_photos_batch(update, context, photos, page=0, header=f"📅 Фото за {date_str}")
        return

    if ftype == "uploaders":
        c.execute("""
            SELECT p.uploaded_by, COUNT(*) as cnt, u.name
            FROM photos p
            LEFT JOIN users u ON u.tg_id = p.uploaded_by
            WHERE p.object_id = ?
            GROUP BY p.uploaded_by
            ORDER BY cnt DESC
        """, (obj_id,))
        rows = c.fetchall()
        conn.close()
        buttons = []
        for r in rows[:25]:
            name = r['name'] or f"id{r['uploaded_by']}"
            buttons.append([InlineKeyboardButton(
                f"👤 {name} ({r['cnt']})",
                callback_data=f"photofilt_upl_{obj_id}_{r['uploaded_by']}"
            )])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"objphotos_{obj_id}")])
        await query.edit_message_text(
            f"👤 Кто загрузил фото «{obj_name}»:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if ftype == "upl":
        tg_id = int(extra) if extra else 0
        c.execute("""
            SELECT p.id, p.file_id, p.stage, p.caption, p.taken_at, p.task_id,
                   t.title as task_title
            FROM photos p
            LEFT JOIN tasks t ON p.task_id = t.id
            WHERE p.object_id = ? AND p.uploaded_by = ?
            ORDER BY p.taken_at DESC
        """, (obj_id, tg_id))
        photos = [dict(r) for r in c.fetchall()]
        c.execute("SELECT name FROM users WHERE tg_id = ?", (tg_id,))
        u = c.fetchone()
        conn.close()
        name = u['name'] if u else f"id{tg_id}"
        context.user_data['photo_filter_key'] = f"upl_{obj_id}_{tg_id}"
        context.user_data['photo_back'] = f"photofilt_uploaders_{obj_id}"
        context.user_data['photo_cache'] = photos
        await query.edit_message_text(f"👤 Фото от {name}\nВсего: {len(photos)}")
        await _show_photos_batch(update, context, photos, page=0, header=f"👤 Фото от {name}")
        return

    if ftype == "assignees":
        c.execute("""
            SELECT t.assigned_to, COUNT(p.id) as cnt, u.name
            FROM photos p
            JOIN tasks t ON p.task_id = t.id
            LEFT JOIN users u ON u.tg_id = t.assigned_to
            WHERE p.object_id = ? AND t.assigned_to IS NOT NULL
            GROUP BY t.assigned_to
            ORDER BY cnt DESC
        """, (obj_id,))
        rows = c.fetchall()
        conn.close()
        if not rows:
            await query.edit_message_text(
                f"🛠 Фото «{obj_name}» по исполнителям\n\n"
                f"Ни одна задача не назначена на исполнителя.\n"
                f"Пока все фото — без исполнителя.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Назад", callback_data=f"objphotos_{obj_id}")]
                ])
            )
            return
        buttons = []
        for r in rows[:25]:
            name = r['name'] or f"id{r['assigned_to']}"
            buttons.append([InlineKeyboardButton(
                f"🛠 {name} ({r['cnt']})",
                callback_data=f"photofilt_asgn_{obj_id}_{r['assigned_to']}"
            )])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"objphotos_{obj_id}")])
        await query.edit_message_text(
            f"🛠 Кто делал задачи «{obj_name}»:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if ftype == "asgn":
        tg_id = int(extra) if extra else 0
        c.execute("""
            SELECT p.id, p.file_id, p.stage, p.caption, p.taken_at, p.task_id,
                   t.title as task_title
            FROM photos p
            JOIN tasks t ON p.task_id = t.id
            WHERE p.object_id = ? AND t.assigned_to = ?
            ORDER BY p.taken_at DESC
        """, (obj_id, tg_id))
        photos = [dict(r) for r in c.fetchall()]
        c.execute("SELECT name FROM users WHERE tg_id = ?", (tg_id,))
        u = c.fetchone()
        conn.close()
        name = u['name'] if u else f"id{tg_id}"
        context.user_data['photo_filter_key'] = f"asgn_{obj_id}_{tg_id}"
        context.user_data['photo_back'] = f"photofilt_assignees_{obj_id}"
        context.user_data['photo_cache'] = photos
        await query.edit_message_text(f"🛠 Фото по задачам от {name}\nВсего: {len(photos)}")
        await _show_photos_batch(update, context, photos, page=0, header=f"🛠 Фото от {name}")
        return

    conn.close()
    await query.edit_message_text(f"🤔 Неизвестный фильтр: {ftype}")


async def handle_photo_page(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Пагинация: показать ещё 3 фото."""
    query = update.callback_query
    await query.answer()
    data = query.data
    if not data.startswith("photopage_"):
        return
    # photopage_<filter_key>_<page>
    parts = data.replace("photopage_", "").rsplit("_", 1)
    page = int(parts[1]) if len(parts) > 1 else 0
    photos = context.user_data.get('photo_cache', [])
    if not photos:
        await query.edit_message_text("❌ Фото потерялись. Открой заново.")
        return
    await _show_photos_batch(update, context, photos, page=page, header="📸 Ещё фото")


# === ОБРАБОТКА ФОТО ===

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ловит фото от пользователя. Если есть photo_for_task — привязываем к задаче. Иначе — стандартный выбор."""
    photo = update.message.photo[-1]
    file_id = photo.file_id

    # === СЦЕНАРИЙ 1: ждали фото для конкретной задачи (после /done) ===
    pft = context.user_data.get('photo_for_task')
    if pft and pft.get('task_id'):
        from datetime import datetime
        conn = get_connection()
        c = conn.cursor()
        c.execute(
            """INSERT INTO photos (object_id, task_id, file_id, caption, stage, uploaded_by, taken_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                pft.get('object_id'),
                pft['task_id'],
                file_id,
                update.message.caption or '',
                'after',
                update.effective_user.id,
                datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            )
        )
        conn.commit()
        conn.close()
        context.user_data['photo_for_task'] = None

        await update.message.reply_text(
            f"✅ Фото сохранено для задачи #{pft['task_id']} (этап: После)",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📋 К задачам", callback_data="menu_tasks")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    # === СЦЕНАРИЙ 2: обычная загрузка (выбор объекта → этап → задача) ===
    context.user_data['pending_photo'] = {
        'file_id': file_id,
        'caption': update.message.caption or '',
    }

    objs = get_all_objects()
    if not objs:
        await update.message.reply_text("❌ Нет объектов. Сначала создай объект.")
        return

    buttons = []
    for o in objs[:20]:
        buttons.append([InlineKeyboardButton(
            f"🏗️ {o['name']}",
            callback_data=f"photo_obj_{o['id']}"
        )])
    buttons.append([InlineKeyboardButton("💳 Распознать чек (OCR)", callback_data="recognize_receipt")])
    buttons.append([InlineKeyboardButton("❌ Отмена", callback_data="menu_back")])

    await update.message.reply_text(
        "📸 Фото получено.\n\nВыбери объект или распознай чек:",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def handle_photo_stage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Выбор этапа фото."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if not data.startswith("photo_obj_"):
        return
    obj_id = int(data.replace("photo_obj_", ""))

    pending = context.user_data.get('pending_photo', {})
    if not pending or 'file_id' not in pending:
        await query.edit_message_text("❌ Фото потерялось. Пришли заново.")
        return

    pending['object_id'] = obj_id
    context.user_data['pending_photo'] = pending

    await query.edit_message_text(
        "📸 Выбери этап:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📸 До (before)", callback_data="photo_stage_before")],
            [InlineKeyboardButton("🔵 Процесс (progress)", callback_data="photo_stage_progress")],
            [InlineKeyboardButton("✅ После (after)", callback_data="photo_stage_after")],
            [InlineKeyboardButton("📄 Документ", callback_data="photo_stage_document")],
            [InlineKeyboardButton("❌ Отмена", callback_data="menu_back")],
        ])
    )


async def handle_photo_task(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Выбор задачи после этапа."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if not data.startswith("photo_stage_"):
        return
    stage = data.replace("photo_stage_", "")

    pending = context.user_data.get('pending_photo', {})
    if not pending or 'file_id' not in pending:
        await query.edit_message_text("❌ Фото потерялось. Пришли заново.")
        return

    pending['stage'] = stage
    context.user_data['pending_photo'] = pending

    # Показываем задачи объекта + «Без задачи»
    obj_id = pending.get('object_id')
    tasks = get_tasks_by_object(obj_id) if obj_id else []
    open_tasks = [t for t in tasks if t['status'] in ('open', 'in_progress')]

    buttons = [[InlineKeyboardButton("📌 Без задачи", callback_data="photo_task_none")]]
    for t in open_tasks[:15]:
        buttons.append([InlineKeyboardButton(
            f"#{t['id']} {t['title'][:35]}",
            callback_data=f"photo_task_{t['id']}"
        )])
    buttons.append([InlineKeyboardButton("❌ Отмена", callback_data="menu_back")])

    await query.edit_message_text(
        "📸 К какой задаче привязать?",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def handle_photo_save(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Сохраняет фото в БД."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if not data.startswith("photo_task_"):
        return
    task_part = data.replace("photo_task_", "")
    task_id = None if task_part == "none" else int(task_part)

    pending = context.user_data.get('pending_photo', {})
    if not pending or 'file_id' not in pending:
        await query.edit_message_text("❌ Фото потерялось. Пришли заново.")
        return

    # Сохраняем в БД
    from datetime import datetime
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        """INSERT INTO photos (object_id, task_id, file_id, caption, stage, uploaded_by, taken_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            pending.get('object_id'),
            task_id,
            pending['file_id'],
            pending.get('caption', ''),
            pending.get('stage', 'progress'),
            update.effective_user.id,
            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        )
    )
    photo_id = c.lastrowid
    conn.commit()
    conn.close()

    obj = get_object(pending.get('object_id')) if pending.get('object_id') else None
    obj_name = obj['name'] if obj else '—'
    stage_names = {'before': '📸 До', 'progress': '🔵 Процесс', 'after': '✅ После', 'document': '📄 Документ'}

    context.user_data['pending_photo'] = None

    await query.edit_message_text(
        f"✅ Фото сохранено!\n\n"
        f"🏗️ Объект: {obj_name}\n"
        f"📊 Этап: {stage_names.get(pending.get('stage'), pending.get('stage'))}\n"
        f"📋 Задача: #{task_id}" if task_id else
        f"✅ Фото сохранено!\n\n"
        f"🏗️ Объект: {obj_name}\n"
        f"📊 Этап: {stage_names.get(pending.get('stage'), pending.get('stage'))}\n"
        f"📋 Без задачи",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🏗️ К объекту", callback_data=f"obj_{pending.get('object_id')}")],
            [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
        ])
    )


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    # DEBUG: печатаем всё, что приходит
    try:
        with open('/tmp/handle_text.log', 'a') as _f:
            _f.write(f"HANDLE_TEXT: text={text!r}, waiting_for={context.user_data.get('waiting_for')!r}\n")
    except Exception:
        pass
    print(f"🔵 HANDLE_TEXT: text={text!r}, waiting_for={context.user_data.get('waiting_for')!r}", flush=True)
    if not text or text.startswith('/'):
        print(f"⚠️ RETURN на строке 2283", flush=True)
        return

    # Размеры комнаты
    if context.user_data.get('waiting_for') in ('measure_first_dim', 'measure_second_dim', 'wall_angle_value', 'wall_niche_width', 'wall_niche_depth', 'wall_niche_height', 'room_height_point', 'room_height_same', 'wall_round_length', 'wall_round_angle_val', 'wall_round_plane_bottom', 'wall_round_plane_middle', 'wall_round_plane_top', 'opening_width', 'opening_height', 'opening_sill', 'opening_offset', 'opening_edit_value', 'comm_offset_x', 'comm_offset_y', 'comm_diameter', 'comm_voltage', 'comm_edit_value', 'comm_size', 'comm_size_w', 'comm_size_h', 'comm_size_d', 'comm_edit_size_part', 'wall_round_opening_width', 'wall_round_opening_height', 'comm_offset_x', 'comm_offset_y', 'comm_diameter', 'comm_voltage', 'comm_edit_value',
                                                  'wall_round_length', 'wall_round_angle_val', 'wall_round_plane_bottom', 'wall_round_plane_middle', 'wall_round_plane_top'):
        from interfaces.telegram.rooms import handle_measure_input
        await handle_measure_input(update, context)
        print(f"⚠️ RETURN на строке 2289", flush=True)
        return

    # Новая комната — просим тип (черновая/чистовая/промежуточная)
    if context.user_data.get('waiting_for') == 'room_name':
        name = text.strip()
        object_id = context.user_data.get('room_object_id')
        context.user_data['room_name_pending'] = name
        context.user_data['waiting_for'] = None
        await update.message.reply_text(
            f"📦 *Новая комната «{name}»*\n\nКакой тип помещения?",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🧱 Черновая", callback_data=f"room_type_{object_id}_rough")],
                [InlineKeyboardButton("✨ Чистовая", callback_data=f"room_type_{object_id}_finish")],
                [InlineKeyboardButton("🔶 Промежуточная", callback_data=f"room_type_{object_id}_mid")],
                [InlineKeyboardButton("⬅️ Отмена", callback_data=f"rooms_list_obj_{object_id}")],
            ])
        )
        print(f"⚠️ RETURN на строке 2307", flush=True)
        return

    # Стена выбрана, но ровная/закругление не нажато → показать кнопки заново
    if context.user_data.get('wall_pos') and context.user_data.get('wall_rounded') is None:
        from interfaces.telegram.rooms import reask_wall_question
        shown = await reask_wall_question(update, context)
        if shown:
            print(f"⚠️ RETURN на строке 2314", flush=True)
            return

    # === ВСЕ CRM-ОЖИДАНИЯ — В САМОМ НАЧАЛЕ, ДО ПАРСЕРА ===

    # CRM: ждём имя нового клиента (для сделки)
    if context.user_data.get('waiting_for') == 'crm_deal_new_client_name':
        name = text.strip()
        context.user_data['crm_new_client_name'] = name
        context.user_data['waiting_for'] = None
        await update.message.reply_text(
            f"👤 Создать клиента «{name}»?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Создать и продолжить сделку", callback_data="crm_new_client_for_deal")],
                [InlineKeyboardButton("❌ Отмена", callback_data="menu_crm")],
            ])
        )
        print(f"⚠️ RETURN на строке 2330", flush=True)
        return

    # CRM: ждём имя клиента (обычный сценарий)
    if context.user_data.get('waiting_for') == 'crm_client_name':
        context.user_data['crm_new_client_name'] = text.strip()
        context.user_data['waiting_for'] = 'crm_client_phone'
        await update.message.reply_text(
            f"👤 Имя: «{text.strip()}»\n\n📞 Теперь телефон (или Пропустить):",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_phone")],
            ])
        )
        print(f"⚠️ RETURN на строке 2342", flush=True)
        return

    if context.user_data.get('waiting_for') == 'crm_client_phone':
        from modules.phone_utils import parse_phone, get_country_label
        raw = text.strip()
        result = parse_phone(raw)
        status = result.get('status')

        if status == 'ok':
            normalized = result['phone']
            country = get_country_label(normalized)
            context.user_data['crm_new_client_phone'] = normalized
            context.user_data['waiting_for'] = 'crm_client_address'
            await update.message.reply_text(
                f"✅ Телефон распознан: {normalized}\n"
                f"{country}\n\n"
                f"📍 Теперь адрес (или Пропустить):",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✏️ Изменить телефон", callback_data="crm_phone_edit")],
                    [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_address")],
                ])
            )
            print(f"⚠️ RETURN на строке 2364", flush=True)
            return

        if status == 'suggest':
            variants = result.get('variants', [])
            context.user_data['phone_variants'] = variants
            buttons = []
            for v in variants:
                label = f"📞 {v}"
                buttons.append([InlineKeyboardButton(label, callback_data=f"crm_phone_pick_{v}")])
            buttons.append([InlineKeyboardButton("✏️ Ввести заново", callback_data="crm_phone_edit")])
            buttons.append([InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_phone")])
            await update.message.reply_text(
                f"🤔 Номер «{raw}» нестандартный.\n\n"
                f"Выбери подходящий вариант:",
                reply_markup=InlineKeyboardMarkup(buttons)
            )
            print(f"⚠️ RETURN на строке 2380", flush=True)
            return

        # invalid
        await update.message.reply_text(
            f"❌ Номер «{raw}» слишком короткий или не распознан.\n\n"
            f"Введи в формате:\n"
            f"• +79991234567 (Россия)\n"
            f"• 89991234567 (Россия)\n"
            f"• 9991234567 (Россия, 10 цифр)\n"
            f"• +491234567890 (Европа)\n\n"
            f"Или нажми «Пропустить».",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✏️ Ввести заново", callback_data="crm_phone_edit")],
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_phone")],
            ])
        )
        print(f"⚠️ RETURN на строке 2396", flush=True)
        return

    if context.user_data.get('waiting_for') == 'crm_client_address':
        context.user_data['crm_new_client_address'] = text.strip()
        context.user_data['waiting_for'] = 'crm_client_source'
        phone = context.user_data.get('crm_new_client_phone')
        phone_line = f"📞 Телефон: {phone}\n" if phone else "📞 Телефон: —\n"
        await update.message.reply_text(
            f"📍 Адрес: {text.strip()}\n\n"
            f"{phone_line}\n"
            f"🔗 Откуда узнал? Или Пропустить:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✏️ Изменить телефон", callback_data="crm_phone_edit")],
                [InlineKeyboardButton("⏭️ Пропустить", callback_data="crm_skip_source")],
            ])
        )
        print(f"⚠️ RETURN на строке 2412", flush=True)
        return

    if context.user_data.get('waiting_for') == 'crm_client_source':
        context.user_data['crm_new_client_source'] = text.strip()
        await _finalize_new_client(update, context)
        print(f"⚠️ RETURN на строке 2417", flush=True)
        return

    # CRM: ждём бюджет сделки — ВАЖНО до парсера
    if context.user_data.get('waiting_for') == 'crm_deal_budget':
        try:
            from modules.parser import parse_amount
            budget = parse_amount(text) or 0
        except Exception:
            budget = 0
        client_id = context.user_data.get('crm_deal_client_id')
        if not client_id:
            await update.message.reply_text("❌ Клиент потерялся. Начни заново.")
            context.user_data['waiting_for'] = None
            print(f"⚠️ RETURN на строке 2430", flush=True)
            return
        from modules.crm import add_deal, get_client
        deal_id = add_deal(client_id=client_id, object_id=None, status='new', budget=budget)
        c = get_client(client_id)
        context.user_data['waiting_for'] = None
        context.user_data['crm_deal_client_id'] = None
        await update.message.reply_text(
            f"✅ Сделка #{deal_id} создана!\n\n"
            f"👤 Клиент: {c['name'] if c else '—'}\n"
            f"💼 Бюджет: {budget} ₽\n"
            f"📊 Статус: 🆕 Новая",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("👥 К клиентам", callback_data="crm_clients")],
                [InlineKeyboardButton("💼 К сделкам", callback_data="crm_deals")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        print(f"⚠️ RETURN на строке 2447", flush=True)
        return

    # CRM: пользователь ввёл имя в режиме выбора клиента
    if context.user_data.get('waiting_for') == 'crm_deal_pick_client':
        name = text.strip()
        from modules.crm import get_clients
        clients = get_clients()
        found = None
        for c in clients:
            if c['name'].lower().strip() == name.lower():
                found = c
                break
        if found:
            context.user_data['crm_deal_client_id'] = found['id']
            context.user_data['waiting_for'] = 'crm_deal_budget'
            await update.message.reply_text(
                f"💼 Клиент: «{found['name']}»\n\nНапиши сумму бюджета сделки (₽):"
            )
            print(f"⚠️ RETURN на строке 2465", flush=True)
            return
        else:
            context.user_data['crm_new_client_name'] = name
            context.user_data['waiting_for'] = None
            await update.message.reply_text(
                f"👤 Клиента «{name}» нет в списке.\n\nСоздать нового и продолжить сделку?",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Создать и продолжить", callback_data="crm_new_client_for_deal")],
                    [InlineKeyboardButton("⬅️ К списку", callback_data="crm_deal_add")],
                    [InlineKeyboardButton("❌ Отмена", callback_data="menu_crm")],
                ])
            )
            print(f"⚠️ RETURN на строке 2477", flush=True)
            return

    # === ЗАПЛАНИРОВАННЫЙ ЗВОНОК ===
    if context.user_data.get('waiting_for') == 'activity_plan_datetime':
        from modules.crm import add_activity, get_client
        from handlers.commands import parse_date
        client_id = context.user_data.get('activity_client_id')
        if not client_id:
            context.user_data['waiting_for'] = None
            await update.message.reply_text('❌ Клиент потерялся.')
            print(f"⚠️ RETURN на строке 2487", flush=True)
            return
        # Парсим дату и время из текста
        parsed = parse_date(text)
        due_str = None
        if parsed:
            due_str = parsed.strftime('%Y-%m-%d')
        add_activity(
            client_id=client_id,
            user_id=update.effective_user.id,
            type_='call',
            description=text.strip(),
            due_date=due_str
        )
        cl = get_client(client_id)
        context.user_data['waiting_for'] = None
        context.user_data['activity_client_id'] = None
        context.user_data['activity_type'] = None
        due_display = parsed.strftime('%d.%m.%Y') if parsed else 'без даты'
        await update.message.reply_text(
            f'✅ Звонок запланирован: {due_display}\n👤 {cl["name"] if cl else "—"}',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton('👤 К клиенту', callback_data=f'client_{client_id}')],
                [InlineKeyboardButton('📋 Активности', callback_data=f'activity_list_{client_id}')],
            ])
        )
        print(f"⚠️ RETURN на строке 2512", flush=True)
        return

    # === ДИАПАЗОН СРОКА (обработка ввода) ===
    if context.user_data.get('range_step') == 'start':
        d = parse_date(text)
        if not d:
            await update.message.reply_text('❌ Не понял дату начала. Попробуй: «завтра», «1.10», «пн», «10.10.2025»')
            print(f"⚠️ RETURN на строке 2519", flush=True)
            return
        context.user_data['range_start'] = d.strftime('%Y-%m-%d')
        context.user_data['range_step'] = 'end'
        await update.message.reply_text(
            f"📆 Старт: {d.strftime('%d.%m.%Y')}\n\n"
            f"Теперь дата конца:"
        )
        print(f"⚠️ RETURN на строке 2526", flush=True)
        return

    if context.user_data.get('range_step') == 'end':
        d_end = parse_date(text)
        if not d_end:
            await update.message.reply_text('❌ Не понял дату конца. Попробуй: «8.10», «+5», «пятница»')
            print(f"⚠️ RETURN на строке 2532", flush=True)
            return
        task_id = context.user_data.get('range_task')
        start = context.user_data.get('range_start')
        from modules.tasks import set_task_range
        from datetime import datetime as _dt
        d_start = _dt.strptime(start, '%Y-%m-%d').date()
        if d_end < d_start:
            await update.message.reply_text('❌ Конец раньше старта. Введи ещё раз.')
            print(f"⚠️ RETURN на строке 2540", flush=True)
            return
        set_task_range(task_id, start, d_end.strftime('%Y-%m-%d'))
        days = (d_end - d_start).days + 1
        context.user_data['range_step'] = None
        context.user_data['range_task'] = None
        context.user_data['range_start'] = None
        await update.message.reply_text(
            f"✅ Срок: {d_start.strftime('%d.%m.%Y')} — {d_end.strftime('%d.%m.%Y')} ({days} дн.)",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton('📋 К задаче', callback_data=f'task_{task_id}')],
                [InlineKeyboardButton('🏠 Меню', callback_data='menu_back')],
            ])
        )
        print(f"⚠️ RETURN на строке 2553", flush=True)
        return

    # === ДЛИТЕЛЬНОСТЬ (обработка ввода) ===
    if context.user_data.get('duration_step') == 'start':
        d = parse_date(text)
        if not d:
            await update.message.reply_text('❌ Не понял дату старта. Попробуй: «завтра», «1.10»')
            print(f"⚠️ RETURN на строке 2560", flush=True)
            return
        context.user_data['duration_start'] = d.strftime('%Y-%m-%d')
        context.user_data['duration_step'] = 'days'
        await update.message.reply_text(
            f"⏳ Старт: {d.strftime('%d.%m.%Y')}\n\n"
            f"Сколько дней? Напиши число (например, 3):"
        )
        print(f"⚠️ RETURN на строке 2567", flush=True)
        return

    if context.user_data.get('duration_step') == 'days':
        try:
            n = int(text.strip())
        except ValueError:
            await update.message.reply_text('❌ Нужно число. Напиши, сколько дней.')
            print(f"⚠️ RETURN на строке 2574", flush=True)
            return
        if n < 1 or n > 365:
            await update.message.reply_text('❌ От 1 до 365 дней.')
            print(f"⚠️ RETURN на строке 2577", flush=True)
            return
        task_id = context.user_data.get('duration_task')
        start = context.user_data.get('duration_start')
        from modules.tasks import set_task_range
        from datetime import datetime as _dt, timedelta
        d_start = _dt.strptime(start, '%Y-%m-%d').date()
        d_end = d_start + timedelta(days=n - 1)
        set_task_range(task_id, start, d_end.strftime('%Y-%m-%d'))
        context.user_data['duration_step'] = None
        context.user_data['duration_task'] = None
        context.user_data['duration_start'] = None
        await update.message.reply_text(
            f"✅ Срок: {d_start.strftime('%d.%m.%Y')} — {d_end.strftime('%d.%m.%Y')} ({n} дн.)",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton('📋 К задаче', callback_data=f'task_{task_id}')],
                [InlineKeyboardButton('🏠 Меню', callback_data='menu_back')],
            ])
        )
        print(f"⚠️ RETURN на строке 2595", flush=True)
        return

    # === АКТИВНОСТИ КЛИЕНТА ===
    if context.user_data.get('waiting_for') == 'activity_text':
        from modules.crm import add_activity, get_client
        client_id = context.user_data.get('activity_client_id')
        atype = context.user_data.get('activity_type')
        if not client_id or not atype:
            context.user_data['waiting_for'] = None
            await update.message.reply_text('❌ Клиент потерялся. Начни заново.')
            print(f"⚠️ RETURN на строке 2605", flush=True)
            return
        add_activity(client_id=client_id, user_id=update.effective_user.id, type_=atype, description=text.strip())
        cl = get_client(client_id)
        context.user_data['waiting_for'] = None
        context.user_data['activity_client_id'] = None
        context.user_data['activity_type'] = None
        type_names = {'call': '📞 Звонок', 'meeting': '🤝 Встреча', 'note': '📝 Заметка'}
        await update.message.reply_text(
            f'✅ {type_names.get(atype, atype)} записан клиенту «{cl["name"] if cl else "—"}»',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton('👤 К клиенту', callback_data=f'client_{client_id}')],
                [InlineKeyboardButton('🏠 Меню', callback_data='menu_back')],
            ])
        )
        print(f"⚠️ RETURN на строке 2619", flush=True)
        return

    # === ДАЛЬШЕ — СТАРАЯ ЛОГИКА (новые задачи, расходы и т.д.) ===

    # === ПРИВЕТСТВИЯ ===
    greetings = ['привет', 'здравствуй', 'здравствуйте', 'хай', 'hi', 'hello', 'ку', 'добрый день', 'доброе утро', 'добрый вечер']
    text_low = text.lower().strip()
    if text_low in greetings or any(text_low.startswith(g) for g in greetings):
        user_name = update.effective_user.first_name or ''
        await update.message.reply_text(
            f"👋 Привет{', ' + user_name if user_name else ''}!\n\n"
            f"Я *Бо 7.7* — помощник по стройке.\n\n"
            f"Что умею:\n"
            f"• «потратил 5000 на материалы Переделкино-2»\n"
            f"• «добавь в Арбат положить паркет»\n"
            f"• «500» — спрошу личный/объект\n"
            f"• /objects, /tasks, /finance — списки\n"
            f"• /help — все команды",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
                [InlineKeyboardButton("⚙️ Помощь", callback_data="menu_help")],
            ])
        )
        print(f"⚠️ RETURN на строке 2643", flush=True)
        return

    # Обработка создания новой задачи
    if context.user_data.get('waiting_for') == 'new_task_text':
        obj = context.user_data.get('pending_task_object')
        if obj:
            tid = create_task(obj['id'], text)
            context.user_data['waiting_for'] = None
            context.user_data['pending_task_object'] = None
            await update.message.reply_text(
                f"✅ Задача «{text}» добавлена в «{obj['name']}»",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📋 К задаче", callback_data=f"task_{tid}")],
                    [InlineKeyboardButton("📋 К задачам", callback_data="menu_tasks")],
                    [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
                ])
            )
            print(f"⚠️ RETURN на строке 2660", flush=True)
            return

    # Обработка создания нового расхода
    if context.user_data.get('waiting_for') == 'new_expense_text':
        obj = context.user_data.get('pending_expense_object')
        if not obj:
            context.user_data['waiting_for'] = None
            await update.message.reply_text(
                "❌ Объект потерялся. Начни заново: «➕ Добавить» → «💰 Расход»",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("➕ Добавить", callback_data="menu_add")],
                    [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
                ])
            )
            print(f"⚠️ RETURN на строке 2674", flush=True)
            return
        if obj:
            amount = parse_amount(text)
            if amount:
                category = None
                _tl = text.lower()
                for _c in ["материалы", "еда", "транспорт", "инструмент"]:
                    if _c in _tl:
                        category = _c
                        break
                if category:
                    add_expense(obj['id'], amount, category)
                    context.user_data['waiting_for'] = None
                    context.user_data['pending_expense_object'] = None
                    await update.message.reply_text(
                        f"\u2705 Расход {amount} \u20bd ({category}) добавлен в \u00ab{obj['name']}\u00bb",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("\U0001F4B0 К финансам", callback_data="menu_finance")],
                            [InlineKeyboardButton("\U0001F3E0 Меню", callback_data="menu_back")],
                        ])
                    )
                    print(f"⚠️ RETURN на строке 2695", flush=True)
                    return
                else:
                    context.user_data['pending_expense'] = {
                        'object_id': obj['id'],
                        'object_name': obj['name'],
                        'amount': amount
                    }
                    context.user_data['waiting_for'] = 'new_expense_category'
                    await update.message.reply_text(
                        f"\U0001F4B0 {amount} \u20bd в \u00ab{obj['name']}\u00bb. За что?",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("\U0001F9F1 Материалы", callback_data="cat_материалы")],
                            [InlineKeyboardButton("\U0001F354 Еда", callback_data="cat_еда")],
                            [InlineKeyboardButton("\U0001F697 Транспорт", callback_data="cat_транспорт")],
                            [InlineKeyboardButton("\U0001F527 Инструмент", callback_data="cat_инструмент")],
                            [InlineKeyboardButton("\U0001F4E6 Прочее", callback_data="cat_прочее")],
                        ])
                    )
                    print(f"⚠️ RETURN на строке 2713", flush=True)
                    return
            else:
                await update.message.reply_text(
                    "\u274c Не понял сумму. Попробуй: \u00ab500\u00bb"
                )
                print(f"⚠️ RETURN на строке 2718", flush=True)
                return

    # Обработка личного расхода
    if context.user_data.get('waiting_for') == 'personal_expense_text':
        # Разбираем: "300 еда" или "1500 инструмент"
        parts = text.strip().split(maxsplit=1)
        amount_str = parts[0] if parts else ''
        category = parts[1].strip() if len(parts) > 1 else 'прочее'
        # Убираем лишние символы
        amount_str = amount_str.replace('₽', '').replace('р', '').replace('руб', '').strip()
        try:
            amount = int(amount_str)
        except ValueError:
            amount = parse_amount(text)
            if not amount:
                await update.message.reply_text(
                    "❌ Не понял сумму. Попробуй: «300 еда»"
                )
                print(f"⚠️ RETURN на строке 2736", flush=True)
                return
        add_personal_expense(amount, category)
        context.user_data['waiting_for'] = None
        await update.message.reply_text(
            f"✅ Личный расход {amount} ₽ ({category}) записан",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💸 К личным", callback_data="menu_personal")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        print(f"⚠️ RETURN на строке 2746", flush=True)
        return

    # Обработка создания нового объекта
    if context.user_data.get('waiting_for') == 'new_object':
        object_id = create_object(text, user_id=update.effective_user.id)
        context.user_data['waiting_for'] = None
        await update.message.reply_text(
            f"✅ Объект «{text}» создан",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏗️ К объекту", callback_data=f"obj_{object_id}")],
                [InlineKeyboardButton("🏗️ К объектам", callback_data="menu_objects")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        print(f"⚠️ RETURN на строке 2760", flush=True)
        return

    # Обработка ввода даты для задачи
    setdate_task = context.user_data.get('setdate_task')
    if setdate_task:
        d = parse_date(text)
        if d:
            # Сохраняем во временное хранилище, ждём подтверждения
            context.user_data['confirm_date'] = {
                'task_id': setdate_task,
                'date': d.strftime('%Y-%m-%d'),
                'date_str': d.strftime('%d.%m.%Y')
            }
            context.user_data['setdate_task'] = None
            # Получаем задачу
            conn = get_connection()
            c = conn.cursor()
            c.execute("SELECT t.title, o.name as obj FROM tasks t LEFT JOIN objects o ON t.object_id = o.id WHERE t.id = ?", (setdate_task,))
            row = c.fetchone()
            conn.close()
            title = row['title'] if row else '?'
            obj = row['obj'] if row and row['obj'] else 'Без объекта'
            await update.message.reply_text(
                f"📋 {title}\n{obj}\n\n📅 Дата: {d.strftime('%d.%m.%Y')}\n\nПодтверди:",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Да", callback_data=f"confirmdate_yes_{setdate_task}_{d.strftime('%Y-%m-%d')}")],
                    [InlineKeyboardButton("❌ Нет", callback_data=f"confirmdate_no_{setdate_task}")],
                ])
            )
            # Автоподтверждение через 30 секунд
            context.job_queue.run_once(
                auto_confirm_date,
                30,
                data={
                    'chat_id': update.effective_chat.id,
                    'task_id': setdate_task,
                    'date': d.strftime('%Y-%m-%d'),
                    'date_str': d.strftime('%d.%m.%Y')
                },
                name=f"confirm_{setdate_task}"
            )
            print(f"⚠️ RETURN на строке 2801", flush=True)
            return
        else:
            await update.message.reply_text(
                "❌ Не понял дату. Попробуй: «завтра», «20.09», «пн», «+3»"
            )
            print(f"⚠️ RETURN на строке 2806", flush=True)
            return

    # Обработка переименования задачи
    rename_task = context.user_data.get('rename_task')
    if rename_task:
        conn = get_connection()
        c = conn.cursor()
        c.execute("UPDATE tasks SET title = ? WHERE id = ?", (text, rename_task))
        conn.commit()
        conn.close()
        context.user_data['rename_task'] = None
        await update.message.reply_text(f"✅ Задача переименована: «{text}»")
        print(f"⚠️ RETURN на строке 2818", flush=True)
        return

    result = parse_message(text)
    action = result.get('action')

    if action == 'ask_expense_type':
        amount = result['amount']
        context.user_data['ask_expense_amount'] = amount
        await update.message.reply_text(
            f"💰 {amount} ₽ — куда записать?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💸 Личный расход", callback_data=f"exp_type_personal_{amount}")],
                [InlineKeyboardButton("🏗️ Расход по объекту", callback_data=f"exp_type_object_{amount}")],
                [InlineKeyboardButton("❌ Отмена", callback_data="menu_back")],
            ])
        )
        print(f"⚠️ RETURN на строке 2834", flush=True)
        return

    if action == 'income':
        from modules.finance import add_income
        obj = result['object']
        amount = result['amount']
        category = result.get('category', 'доход')
        add_income(obj['id'], amount, category)
        await update.message.reply_text(
            f"💰 Доход {amount} ₽ ({category}) добавлен в «{obj['name']}»"
        )
        print(f"⚠️ RETURN на строке 2845", flush=True)
        return

    if action == 'expense':
        obj = result['object']
        amount = result['amount']
        category = result['category']
        # Известные категории
        known_categories = ['материалы', 'еда', 'транспорт', 'инструмент', 'сантехника', 'электрика', 'покраска']
        # Если категория явно из списка — записываем сразу
        if category and category in known_categories:
            add_expense(obj['id'], amount, category)
            await update.message.reply_text(
                f"✅ Расход {amount} ₽ ({category}) добавлен в «{obj['name']}»"
            )
            print(f"⚠️ RETURN на строке 2859", flush=True)
            return
        # Иначе — спрашиваем категорию
        context.user_data['pending_expense'] = {
            'object_id': obj['id'],
            'object_name': obj['name'],
            'amount': amount
        }
        await update.message.reply_text(
            f"💰 Расход {amount} ₽ в «{obj['name']}»\n\nЗа что?",
            reply_markup=expense_category_keyboard()
        )
        print(f"⚠️ RETURN на строке 2870", flush=True)
        return

    if action == 'add_task':
        obj = result['object']
        title = result['title']
        tid = create_task(obj['id'], title)
        await update.message.reply_text(
            f"✅ Задача «{title}» добавлена в «{obj['name']}». ID: {tid}"
        )
        print(f"⚠️ RETURN на строке 2879", flush=True)
        return

    if action == 'done_task':
        obj = result['object']
        task = result['task']
        close_task(task['id'], user_id=update.effective_user.id)
        await update.message.reply_text(
            f"✅ Задача «{task['title']}» в «{obj['name']}» выполнена!"
        )
        print(f"⚠️ RETURN на строке 2888", flush=True)
        return

    if action == 'done_task_not_found':
        obj = result['object']
        await update.message.reply_text(
            f"❌ В «{obj['name']}» не нашёл задачу с «{result['query']}». Посмотри /tasks"
        )
        print(f"⚠️ RETURN на строке 2895", flush=True)
        return

    if action == 'finance':
        obj = result['object']
        f = get_finance_summary(obj['id'])
        await update.message.reply_text(
            f"💰 {obj['name']}\n\nДоход: {f['income']} ₽\nРасход: {f['expense']} ₽\nБаланс: {f['balance']} ₽"
        )
        print(f"⚠️ RETURN на строке 2903", flush=True)
        return

    if action == 'list_tasks':
        tasks = get_active_tasks()
        if not tasks:
            await update.message.reply_text("✅ Нет активных задач")
            print(f"⚠️ RETURN на строке 2909", flush=True)
            return
        text_out = f"📋 Активные задачи ({len(tasks)}):\n\n"
        for t in tasks[:15]:
            text_out += f"• #{t['id']} {t['title']}\n"
        await update.message.reply_text(text_out)
        print(f"⚠️ RETURN на строке 2914", flush=True)
        return

    if action == 'list_objects':
        objs = get_all_objects()
        text_out = f"🏗️ Объекты ({len(objs)}):\n\n"
        for o in objs:
            text_out += f"• {o['name']}\n"
        await update.message.reply_text(text_out)
        print(f"⚠️ RETURN на строке 2922", flush=True)
        return

    if action == 'choose_object':
        objects = result['objects']
        intent = result.get('intent', 'expense')
        amount = result.get('amount')
        category = result.get('category', 'прочее')
        if intent == 'add_task':
            context.user_data['pending_task_title'] = result.get('original_text', '')
        await update.message.reply_text(
            f"🤔 Нашёл несколько объектов. Какой именно?",
            reply_markup=make_choose_keyboard(objects, intent, amount, category)
        )
        print(f"⚠️ RETURN на строке 2935", flush=True)
        return

    # === CRM: ожидаем бюджет сделки ===

    # === УМНЫЙ FALLBACK: сразу ищем похожие объекты ===
    context.user_data['unknown_text'] = text

    # Ищем похожие объекты через rapidfuzz
    print(f"🔍 UNKNOWN: text={text!r}", flush=True)
    from rapidfuzz import process as rf_process, fuzz as rf_fuzz
    all_objs = get_all_objects()
    print(f"🔍 UNKNOWN: all_objs={len(all_objs)}", flush=True)
    text_lower = text.strip().lower()
    exact_match = None
    similar = []
    for o in all_objs:
        if (o.get('name') or '').lower() == text_lower:
            exact_match = o
            break
    if not exact_match and all_objs:
        names = [o.get('name') or '' for o in all_objs]
        matches = rf_process.extract(text, names, scorer=rf_fuzz.WRatio, limit=5)
        for name, score, idx in matches:
            if score >= 55:
                similar.append((all_objs[idx], score))

    if exact_match:
        context.user_data['unknown_text'] = None
        await update.message.reply_text(
            f"✅ *Нашёл объект!*\n\n"
            f"🏗️ {exact_match['name']}",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏗️ Открыть объект", callback_data=f"obj_{exact_match['id']}")],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
            ])
        )
        return

    buttons = []
    if similar:
        for o, score in similar:
            buttons.append([InlineKeyboardButton(
                f"🏗️ {o['name']} ({int(score)}%)",
                callback_data=f"obj_{o['id']}"
            )])
    buttons.append([InlineKeyboardButton(f"➕ Создать новый объект «{text[:40]}»", callback_data="unknown_as_object")])
    buttons.append([InlineKeyboardButton("👤 Это клиент", callback_data="unknown_as_client"),
                    InlineKeyboardButton("📋 Это задача", callback_data="unknown_as_task")])
    buttons.append([InlineKeyboardButton("💰 Расход на объект", callback_data="unknown_as_expense"),
                    InlineKeyboardButton("💸 Личный расход", callback_data="unknown_as_personal")])
    buttons.append([InlineKeyboardButton("❌ Ничего", callback_data="unknown_cancel")])

    header = f"🤔 Не распознал: «{text[:80]}»\n\n"
    if similar:
        header += f"🔍 Нашёл {len(similar)} похожих объектов.\nВыбери:"
    else:
        header += "Что с этим сделать?"

    await update.message.reply_text(
        header,
        reply_markup=InlineKeyboardMarkup(buttons)
    )


# === УТОЧНЕНИЕ ОБЪЕКТА ===

async def handle_choose_object(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает кнопки выбора объекта"""
    query = update.callback_query
    await query.answer()
    data = query.data

    # Формат: choose_obj_<intent>_<object_id>_<amount>_<category>
    parts = data.split('_')
    intent = parts[2]
    object_id = int(parts[3])
    amount = int(parts[4]) if len(parts) > 4 and parts[4] != 'none' else None
    category = parts[5] if len(parts) > 5 else 'прочее'

    obj = get_object(object_id)
    if not obj:
        await query.edit_message_text("❌ Объект не найден")
        return

    if intent == 'expense' and amount:
        # Сохраняем в user_data и спрашиваем категорию
        context.user_data['pending_expense'] = {
            'object_id': obj['id'],
            'object_name': obj['name'],
            'amount': amount
        }
        await query.edit_message_text(
            f"💰 Расход {amount} ₽ в «{obj['name']}»\n\nЗа что?",
            reply_markup=expense_category_keyboard()
        )
        return

    if intent == 'add_task':
        title = context.user_data.get('pending_task_title', '')
        tid = create_task(obj['id'], title)
        await query.edit_message_text(
            f"✅ Задача «{title}» добавлена в «{obj['name']}». ID: {tid}"
        )
        return

    if intent == 'done_task':
        tasks = get_tasks_by_object(obj['id'])
        for t in tasks:
            if t['status'] != 'done':
                close_task(t['id'], user_id=update.effective_user.id)
                await query.edit_message_text(
                    f"✅ Задача «{t['title']}» в «{obj['name']}» выполнена!"
                )
                return
        await query.edit_message_text(f"❌ В «{obj['name']}» нет открытых задач")
        return


def make_choose_keyboard(objects, intent, amount=None, category=None):
    """Создаёт клавиатуру выбора объекта"""
    buttons = []
    for o in objects:
        if amount:
            cb = f"choose_obj_{intent}_{o['id']}_{amount}_{category}"
        else:
            cb = f"choose_obj_{intent}_{o['id']}_none_none"
        buttons.append([InlineKeyboardButton(f"🏗️ {o['name']}", callback_data=cb)])
    return InlineKeyboardMarkup(buttons)


# === ВЫБОР КАТЕГОРИИ РАСХОДА ===

def expense_category_keyboard():
    """Клавиатура категорий расходов"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🧱 Материалы", callback_data="cat_материалы")],
        [InlineKeyboardButton("🍔 Еда", callback_data="cat_еда")],
        [InlineKeyboardButton("🚕 Транспорт", callback_data="cat_транспорт")],
        [InlineKeyboardButton("🔧 Инструмент", callback_data="cat_инструмент")],
        [InlineKeyboardButton("📦 Прочее", callback_data="cat_прочее")],
    ])


async def handle_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора категории"""
    query = update.callback_query
    await query.answer()

    pending = context.user_data.get('pending_expense')
    if not pending:
        await query.edit_message_text("❌ Данные о расходе потеряны")
        return

    category = query.data.replace("cat_", "")
    add_expense(pending['object_id'], pending['amount'], category)
    await query.edit_message_text(
        f"✅ Расход {pending['amount']} ₽ ({category}) добавлен в «{pending['object_name']}»"
    )
    context.user_data['pending_expense'] = None


# === ФИНАНСЫ: СВОДКА + КНОПКИ ===

from modules.finance import get_all_finance_summary


def format_money(amount):
    """Форматирует число с разделителями"""
    return f"{amount:,}".replace(",", " ")


def finance_keyboard():
    """Клавиатура для сводки финансов"""
    data = get_all_finance_summary()
    buttons = []
    # Кнопки по объектам, у которых есть финансы
    for o in data['objects']:
        if o['income'] > 0 or o['expense'] > 0:
            icon = "🟢" if o['balance'] >= 0 else "🔴"
            buttons.append([InlineKeyboardButton(
                f"{icon} {o['name']}: {o['balance']:+} ₽",
                callback_data=f"finobj_{o['id']}"
            )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")])
    return InlineKeyboardMarkup(buttons)


def format_finance_summary():
    """Формирует текст общей сводки"""
    data = get_all_finance_summary()
    text = "💰 ФИНАНСЫ\n\n"
    text += "📊 ОБЩАЯ СВОДКА\n"
    text += f"Доход: {format_money(data['total_income'])} ₽\n"
    text += f"Расход: {format_money(data['total_expense'])} ₽\n"
    text += f"Баланс: {format_money(data['total_balance'])} ₽\n\n"
    text += "🏗️ ПО ОБЪЕКТАМ (нажми для деталей):"
    return text


async def show_finance_summary(update, context):
    """Показывает сводку финансов с кнопками"""
    await update.message.reply_text(
        format_finance_summary(),
        reply_markup=finance_keyboard()
    )


def tasks_keyboard():
    """Клавиатура активных задач"""
    from modules.tasks import get_active_tasks
    tasks = get_active_tasks()
    buttons = []
    for t in tasks[:20]:
        buttons.append([InlineKeyboardButton(
            f"#{t['id']} {t['title'][:40]}",
            callback_data=f"task_{t['id']}"
        )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")])
    return InlineKeyboardMarkup(buttons)


def tasks_keyboard_by_object():
    """Клавиатура задач по объектам"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        SELECT DISTINCT o.id, o.name, COUNT(t.id) as cnt
        FROM objects o
        JOIN tasks t ON t.object_id = o.id
        WHERE t.status IN ('open', 'in_progress') AND o.status IN ('active', 'paused', 'waiting')
        GROUP BY o.id, o.name
        ORDER BY o.name
    """)
    rows = c.fetchall()
    conn.close()

    buttons = []
    for r in rows:
        buttons.append([InlineKeyboardButton(
            f"🏗️ {r['name']} ({r['cnt']})",
            callback_data=f"objtasks_{r['id']}"
        )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")])
    return InlineKeyboardMarkup(buttons)


# === КАРТОЧКА ЗАДАЧИ ===

def task_card_keyboard(task_id, deadline=None):
    """Клавиатура карточки задачи"""
    buttons = [
        [InlineKeyboardButton("📅 Срок", callback_data=f"taskdate_{task_id}")],
    ]
    if deadline:
        buttons.append([InlineKeyboardButton("🚫 Убрать срок", callback_data=f"tasknodate_{task_id}")])
    buttons += [
        [InlineKeyboardButton("👤 Назначить", callback_data=f"taskassign_{task_id}")],
        [InlineKeyboardButton("🔴 Приоритет", callback_data=f"taskprio_{task_id}")],
        [InlineKeyboardButton("✏️ Название", callback_data=f"taskrename_{task_id}")],
        [InlineKeyboardButton("✅ Выполнить", callback_data=f"taskdone_{task_id}")],
        [InlineKeyboardButton("❌ Удалить", callback_data=f"taskdel_{task_id}")],
        [InlineKeyboardButton("⬅ К задачам", callback_data="menu_tasks")],
    ]
    return InlineKeyboardMarkup(buttons)
def task_date_keyboard(task_id):
    """Клавиатура выбора срока"""
    from datetime import date, timedelta
    today = date.today()
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"Сегодня ({today.strftime('%d.%m')})", callback_data=f"setdate_{task_id}_today")],
        [InlineKeyboardButton(f"Завтра ({(today+timedelta(days=1)).strftime('%d.%m')})", callback_data=f"setdate_{task_id}_tomorrow")],
        [InlineKeyboardButton(f"Послезавтра ({(today+timedelta(days=2)).strftime('%d.%m')})", callback_data=f"setdate_{task_id}_dayafter")],
        [InlineKeyboardButton(f"Через 3 дня ({(today+timedelta(days=3)).strftime('%d.%m')})", callback_data=f"setdate_{task_id}_3days")],
        [InlineKeyboardButton(f"Через неделю ({(today+timedelta(days=7)).strftime('%d.%m')})", callback_data=f"setdate_{task_id}_week")],
        [InlineKeyboardButton("📆 Диапазон (с X по Y)", callback_data=f"setrange_{task_id}")],
        [InlineKeyboardButton("⏳ Длительность (старт + N)", callback_data=f"setduration_{task_id}")],
        [InlineKeyboardButton("✏️ Ввести дату вручную", callback_data=f"taskdate_manual_{task_id}")],
        [InlineKeyboardButton("⬅️ Назад", callback_data=f"task_{task_id}")],
    ])


def task_priority_keyboard(task_id):
    """Клавиатура приоритета"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔴 Высокий", callback_data=f"setprio_{task_id}_high")],
        [InlineKeyboardButton("🟡 Средний", callback_data=f"setprio_{task_id}_medium")],
        [InlineKeyboardButton("🟢 Низкий", callback_data=f"setprio_{task_id}_low")],
        [InlineKeyboardButton("⬅️ Назад", callback_data=f"task_{task_id}")],
    ])


async def show_task_card(query, task_id, message=None):
    """Показывает карточку задачи"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        SELECT t.id, t.title, t.status, t.priority, t.deadline, t.assigned_to,
               o.name as object_name
        FROM tasks t
        LEFT JOIN objects o ON t.object_id = o.id
        WHERE t.id = ?
    """, (task_id,))
    row = c.fetchone()
    conn.close()

    if not row:
        await query.edit_message_text("Задача не найдена")
        return

    priority_map = {'high': 'Высокий', 'medium': 'Средний', 'low': 'Низкий'}
    deadline_str = 'не указан'
    if row['deadline']:
        try:
            from datetime import datetime
            d = datetime.strptime(row['deadline'], '%Y-%m-%d').date()
            deadline_str = d.strftime('%d.%m.%Y')
        except:
            deadline_str = row['deadline']

    text = f"📋 {row['title']}\n\n"
    text += f"Объект: {row['object_name'] or 'Без объекта'}\n"
    # Диапазон (если задан)
    try:
        conn2 = get_connection()
        cc = conn2.cursor()
        cc.execute('SELECT deadline_start, deadline_end FROM tasks WHERE id = ?', (task_id,))
        rr = cc.fetchone()
        conn2.close()
        if rr and rr['deadline_start'] and rr['deadline_end']:
            from datetime import datetime as _dt
            try:
                d1 = _dt.strptime(rr['deadline_start'], '%Y-%m-%d').date()
                d2 = _dt.strptime(rr['deadline_end'], '%Y-%m-%d').date()
                days = (d2 - d1).days + 1
                deadline_str = f"{d1.strftime('%d.%m.%Y')} — {d2.strftime('%d.%m.%Y')} ({days} дн.)"
            except Exception:
                pass
    except Exception:
        pass
    text += f"Срок: {deadline_str}\n"
    text += f"Приоритет: {priority_map.get(row['priority'], row['priority'])}\n"
    # Исполнитель
    assigned = row['assigned_to'] if 'assigned_to' in row.keys() else None
    if assigned:
        try:
            from modules.users import get_user
            u = get_user(assigned)
            uname = u.get('name') if u else f'id{assigned}'
        except Exception:
            uname = f'id{assigned}'
        text += f"👤 Исполнитель: {uname}\n"
    else:
        text += f"👤 Исполнитель: —\n"

    await query.edit_message_text(text, reply_markup=task_card_keyboard(task_id, row['deadline']))



async def handle_task_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка действий с задачей"""
    query = update.callback_query
    await query.answer()
    data = query.data
    from datetime import date, timedelta

    # Назначить исполнителя
    if data.startswith("taskassign_"):
        from modules.users import get_all_users
        task_id = int(data.replace("taskassign_", ""))
        all_users = get_all_users()
        # Только master/prorab/designer
        workers = [u for u in all_users if u.get('role') in ('master', 'prorab', 'designer', 'admin')]
        buttons = []
        for u in workers:
            label = f"👤 {u.get('name', '—')[:30]}"
            buttons.append([InlineKeyboardButton(label, callback_data=f"setassigned_{task_id}_{u['tg_id']}")])
        buttons.append([InlineKeyboardButton("🚫 Снять назначение", callback_data=f"setassigned_{task_id}_none")])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"task_{task_id}")])
        if not workers:
            await query.edit_message_text(
                f"👤 Некому назначить.\n\nДобавь юзеров через /users.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Назад", callback_data=f"task_{task_id}")],
                ])
            )
            return
        await query.edit_message_text(
            f"👤 Назначить задачу #{task_id} на:",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
        return

    if data.startswith("setassigned_"):
        from modules.tasks import assign_task
        from modules.users import get_user
        parts = data.replace("setassigned_", "").split("_")
        task_id = int(parts[0])
        if parts[1] == "none":
            assign_task(task_id, None)
            await show_task_card(query, task_id)
            return
        tg_id = int(parts[1])
        assign_task(task_id, tg_id)
        u = get_user(tg_id)
        uname = u.get('name') if u else f'id{tg_id}'
        await show_task_card(query, task_id)
        return

    # Диапазон — старт
    if data.startswith("setrange_"):
        from datetime import date as _date
        task_id = int(data.replace("setrange_", ""))
        context.user_data['range_task'] = task_id
        context.user_data['range_step'] = 'start'
        today = _date.today()
        text_cal, kb = build_calendar(today.year, today.month, callback_prefix='cal')
        await query.edit_message_text(
            "📆 Диапазон — выбери дату СТАРТА:\n\n" + text_cal,
            reply_markup=kb
        )
        return

    # Длительность — старт
    if data.startswith("setduration_"):
        from datetime import date as _date
        task_id = int(data.replace("setduration_", ""))
        context.user_data['duration_task'] = task_id
        context.user_data['duration_step'] = 'start'
        today = _date.today()
        text_cal, kb = build_calendar(today.year, today.month, callback_prefix='cal')
        await query.edit_message_text(
            "⏳ Длительность — выбери дату СТАРТА:\n\n" + text_cal,
            reply_markup=kb
        )
        return

    # Календарь: игнор
    if data == "cal_ignore":
        return

    # Календарь: навигация
    if data.startswith("cal_nav_"):
        parts = data.replace("cal_nav_", "").split("_")
        year, month = int(parts[0]), int(parts[1])
        text, kb = build_calendar(year, month)
        await query.edit_message_text(text, reply_markup=kb)
        return

    # Календарь: выбор дня
    if data.startswith("cal_day_") or data.startswith("cal_quick_"):
        if data.startswith("cal_day_"):
            parts = data.replace("cal_day_", "").split("_")
            year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
            date_iso = f"{year:04d}-{month:02d}-{day:02d}"
        else:
            date_iso = data.replace("cal_quick_", "")
        # Определяем контекст: диапазон или длительность
        from datetime import datetime as _dt
        d = _dt.strptime(date_iso, "%Y-%m-%d").date()
        if context.user_data.get('range_step') == 'start':
            context.user_data['range_start'] = date_iso
            context.user_data['range_step'] = 'end'
            text, kb = build_calendar(d.year, d.month)
            await query.edit_message_text(
                f"📆 Старт: {d.strftime('%d.%m.%Y')}\n\nТеперь дата конца:",
                reply_markup=kb
            )
            return
        if context.user_data.get('range_step') == 'end':
            task_id = context.user_data.get('range_task')
            start = context.user_data.get('range_start')
            from modules.tasks import set_task_range
            d_start = _dt.strptime(start, '%Y-%m-%d').date()
            if d < d_start:
                await query.edit_message_text('❌ Конец раньше старта. Выбери ещё раз:')
                return
            set_task_range(task_id, start, date_iso)
            days = (d - d_start).days + 1
            context.user_data['range_step'] = None
            context.user_data['range_task'] = None
            context.user_data['range_start'] = None
            await query.edit_message_text(
                f"✅ Срок: {d_start.strftime('%d.%m.%Y')} — {d.strftime('%d.%m.%Y')} ({days} дн.)",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton('📋 К задаче', callback_data=f'task_{task_id}')],
                    [InlineKeyboardButton('🏠 Меню', callback_data='menu_back')],
                ])
            )
            return
        if context.user_data.get('duration_step') == 'start':
            context.user_data['duration_start'] = date_iso
            context.user_data['duration_step'] = 'days'
            await query.edit_message_text(
                f"⏳ Старт: {d.strftime('%d.%m.%Y')}\n\nСколько дней? Напиши число:",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton('1', callback_data=f'dur_days_{date_iso}_1'),
                     InlineKeyboardButton('3', callback_data=f'dur_days_{date_iso}_3'),
                     InlineKeyboardButton('5', callback_data=f'dur_days_{date_iso}_5')],
                    [InlineKeyboardButton('7', callback_data=f'dur_days_{date_iso}_7'),
                     InlineKeyboardButton('14', callback_data=f'dur_days_{date_iso}_14'),
                     InlineKeyboardButton('30', callback_data=f'dur_days_{date_iso}_30')],
                ])
            )
            return
        # Если контекста нет — просто ничего
        await query.edit_message_text(f'📅 {d.strftime("%d.%m.%Y")}')
        return

    # Длительность: установка через кнопки
    if data.startswith("dur_days_"):
        parts = data.replace("dur_days_", "").rsplit("_", 1)
        date_iso = parts[0]
        n = int(parts[1])
        task_id = context.user_data.get('duration_task')
        from modules.tasks import set_task_range
        from datetime import datetime as _dt, timedelta
        d_start = _dt.strptime(date_iso, '%Y-%m-%d').date()
        d_end = d_start + timedelta(days=n - 1)
        set_task_range(task_id, date_iso, d_end.strftime('%Y-%m-%d'))
        context.user_data['duration_step'] = None
        context.user_data['duration_task'] = None
        context.user_data['duration_start'] = None
        await query.edit_message_text(
            f"✅ Срок: {d_start.strftime('%d.%m.%Y')} — {d_end.strftime('%d.%m.%Y')} ({n} дн.)",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton('📋 К задаче', callback_data=f'task_{task_id}')],
                [InlineKeyboardButton('🏠 Меню', callback_data='menu_back')],
            ])
        )
        return

    # Выполнить
    if data.startswith("taskdone_"):
        task_id = int(data.split("_")[1])
        close_task(task_id, user_id=update.effective_user.id)
        await query.edit_message_text(
            "✅ Задача выполнена!",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ К задачам", callback_data="menu_tasks")]
            ])
        )
        return

    # Удалить
    if data.startswith("taskdel_"):
        task_id = int(data.split("_")[1])
        conn = get_connection()
        c = conn.cursor()
        c.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        conn.commit()
        conn.close()
        await query.edit_message_text(
            "❌ Задача удалена",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ К задачам", callback_data="menu_tasks")]
            ])
        )
        return

    # Показать карточку
    if data.startswith("task_") and not any(data.startswith(p) for p in ["taskdate_", "taskdone_", "taskdel_", "taskprio_", "taskrename_"]):
        try:
            task_id = int(data.split("_")[1])
            await show_task_card(query, task_id)
        except:
            pass
        return

    # Выбор срока
    if data.startswith("taskdate_"):
        parts = data.split("_")
        # taskdate_manual_<id> — ручной ввод
        if len(parts) >= 2 and parts[1] == "manual":
            task_id = int(parts[2])
            context.user_data['setdate_task'] = task_id
            # Показываем задачу
            conn = get_connection()
            c = conn.cursor()
            c.execute("SELECT t.title, o.name as obj FROM tasks t LEFT JOIN objects o ON t.object_id = o.id WHERE t.id = ?", (task_id,))
            row = c.fetchone()
            conn.close()
            title = row['title'] if row else '?'
            obj = row['obj'] if row and row['obj'] else 'Без объекта'
            await query.edit_message_text(
                f"📋 {title}\n{obj}\n\nНапиши дату:"
            )
            return
        # taskdate_<id> — обычный выбор
        task_id = int(parts[1])
        await query.edit_message_text(
            "📅 Выбери срок:",
            reply_markup=task_date_keyboard(task_id)
        )
        return


    # Убрать срок
    if data.startswith("tasknodate_"):
        task_id = int(data.replace("tasknodate_", ""))
        conn = get_connection()
        c = conn.cursor()
        c.execute("UPDATE tasks SET deadline = NULL WHERE id = ?", (task_id,))
        conn.commit()
        c.execute("SELECT t.title, o.name as obj FROM tasks t LEFT JOIN objects o ON t.object_id = o.id WHERE t.id = ?", (task_id,))
        row = c.fetchone()
        conn.close()
        title = row['title'] if row else '?'
        obj = row['obj'] if row and row['obj'] else 'Без объекта'
        await query.edit_message_text(
            f"🚫 Срок убран у задачи «{title}» ({obj})"
        )
        return
    # Установка срока
    if data.startswith("setdate_"):
        parts = data.split("_")
        task_id = int(parts[1])
        mode = parts[2]
        today = date.today()
        if mode == "today":
            new_date = today
        elif mode == "tomorrow":
            new_date = today + timedelta(days=1)
        elif mode == "dayafter":
            new_date = today + timedelta(days=2)
        elif mode == "3days":
            new_date = today + timedelta(days=3)
        elif mode == "week":
            new_date = today + timedelta(days=7)
        else:
            new_date = today
        conn = get_connection()
        c = conn.cursor()
        c.execute("UPDATE tasks SET deadline = ? WHERE id = ?", (new_date.strftime('%Y-%m-%d'), task_id))
        conn.commit()
        conn.close()
        await show_task_card(query, task_id)
        return

    # Выбор приоритета
    if data.startswith("taskprio_"):
        task_id = int(data.split("_")[1])
        await query.edit_message_text(
            "🔴 Выбери приоритет:",
            reply_markup=task_priority_keyboard(task_id)
        )
        return

    # Установка приоритета
    if data.startswith("setprio_"):
        parts = data.split("_")
        task_id = int(parts[1])
        prio = parts[2]
        conn = get_connection()
        c = conn.cursor()
        c.execute("UPDATE tasks SET priority = ? WHERE id = ?", (prio, task_id))
        conn.commit()
        conn.close()
        await show_task_card(query, task_id)
        return

    # Переименовать
    if data.startswith("taskrename_"):
        task_id = int(data.split("_")[1])
        context.user_data['rename_task'] = task_id
        await query.edit_message_text("✏️ Напиши новое название задачи:")
        return




import calendar as _cal
from datetime import date as _date

def build_calendar(year: int, month: int, callback_prefix: str = 'cal'):
    """Строит (text, keyboard) для календаря месяца."""
    month_names = ['', 'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
                   'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь']
    text = f'📅 {month_names[month]} {year}\n\nВыбери дату:'

    # Навигация
    prev_month = month - 1
    prev_year = year
    if prev_month < 1:
        prev_month = 12
        prev_year -= 1
    next_month = month + 1
    next_year = year
    if next_month > 12:
        next_month = 1
        next_year += 1

    buttons = [[
        InlineKeyboardButton('◀️', callback_data=f'{callback_prefix}_nav_{prev_year}_{prev_month}'),
        InlineKeyboardButton(f'{month_names[month]} {year}', callback_data='cal_ignore'),
        InlineKeyboardButton('▶️', callback_data=f'{callback_prefix}_nav_{next_year}_{next_month}'),
    ]]
    # Дни недели
    buttons.append([
        InlineKeyboardButton('Пн', callback_data='cal_ignore'),
        InlineKeyboardButton('Вт', callback_data='cal_ignore'),
        InlineKeyboardButton('Ср', callback_data='cal_ignore'),
        InlineKeyboardButton('Чт', callback_data='cal_ignore'),
        InlineKeyboardButton('Пт', callback_data='cal_ignore'),
        InlineKeyboardButton('Сб', callback_data='cal_ignore'),
        InlineKeyboardButton('Вс', callback_data='cal_ignore'),
    ])
    # Сетка
    cal = _cal.Calendar(firstweekday=0)
    month_days = cal.monthdayscalendar(year, month)
    today = _date.today()
    for week in month_days:
        row = []
        for day in week:
            if day == 0:
                row.append(InlineKeyboardButton(' ', callback_data='cal_ignore'))
            else:
                label = str(day)
                if year == today.year and month == today.month and day == today.day:
                    label = f'•{day}'
                row.append(InlineKeyboardButton(label, callback_data=f'{callback_prefix}_day_{year}_{month}_{day}'))
        buttons.append(row)
    # Быстрые кнопки
    from datetime import timedelta as _td
    today_d = _date.today()
    tomorrow = today_d + _td(days=1)
    week = today_d + _td(days=7)
    buttons.append([
        InlineKeyboardButton('Сегодня', callback_data=f'{callback_prefix}_quick_{today_d.strftime("%Y-%m-%d")}'),
        InlineKeyboardButton('Завтра', callback_data=f'{callback_prefix}_quick_{tomorrow.strftime("%Y-%m-%d")}'),
        InlineKeyboardButton('+7', callback_data=f'{callback_prefix}_quick_{week.strftime("%Y-%m-%d")}'),
    ])
    return text, InlineKeyboardMarkup(buttons)

def parse_date(text):
    """Парсит дату из текста. Возвращает date или None"""
    from datetime import datetime, date, timedelta
    import re

    text = text.strip().lower()
    today = date.today()

    if text in ['сегодня', 'today']:
        return today
    if text in ['завтра', 'tomorrow']:
        return today + timedelta(days=1)
    if text in ['послезавтра']:
        return today + timedelta(days=2)
    if text in ['через неделю', 'неделя']:
        return today + timedelta(days=7)

    m = re.search(r'через\s+(\d+)\s*дн', text)
    if m:
        return today + timedelta(days=int(m.group(1)))

    m = re.match(r'^\+(\d+)д?$', text)
    if m:
        return today + timedelta(days=int(m.group(1)))

    weekdays = {
        'понедельник': 0, 'пн': 0,
        'вторник': 1, 'вт': 1,
        'среда': 2, 'ср': 2,
        'четверг': 3, 'чт': 3,
        'пятница': 4, 'пт': 4,
        'суббота': 5, 'сб': 5,
        'воскресенье': 6, 'вс': 6,
    }
    for name, num in weekdays.items():
        if text.startswith(name):
            days_ahead = (num - today.weekday()) % 7
            if days_ahead == 0:
                days_ahead = 7
            return today + timedelta(days=days_ahead)

    months = {
        'января': 1, 'январь': 1, 'янв': 1,
        'февраля': 2, 'февраль': 2, 'фев': 2,
        'марта': 3, 'март': 3, 'мар': 3,
        'апреля': 4, 'апрель': 4, 'апр': 4,
        'мая': 5, 'май': 5,
        'июня': 6, 'июнь': 6, 'июн': 6,
        'июля': 7, 'июль': 7, 'июл': 7,
        'августа': 8, 'август': 8, 'авг': 8,
        'сентября': 9, 'сентябрь': 9, 'сен': 9, 'сент': 9,
        'октября': 10, 'октябрь': 10, 'окт': 10,
        'ноября': 11, 'ноябрь': 11, 'ноя': 11,
        'декабря': 12, 'декабрь': 12, 'дек': 12,
    }
    m = re.search(r'(\d{1,2})\s+([а-яё]+)(?:\s+(\d{4}))?', text)
    if m:
        day = int(m.group(1))
        month_name = m.group(2)
        year = int(m.group(3)) if m.group(3) else today.year
        for name, num in months.items():
            if month_name.startswith(name) or name.startswith(month_name):
                try:
                    result = date(year, num, day)
                    if result < today and not m.group(3):
                        result = date(year + 1, num, day)
                    return result
                except:
                    pass

    m = re.search(r'(\d{1,2})[.\-/](\d{1,2})(?:[.\-/](\d{2,4}))?', text)
    if m:
        day = int(m.group(1))
        month = int(m.group(2))
        year_str = m.group(3)
        if year_str:
            year = int(year_str)
            if year < 100:
                year += 2000
        else:
            year = today.year
        try:
            result = date(year, month, day)
            if result < today and not year_str:
                result = date(year + 1, month, day)
            return result
        except:
            pass

    m = re.match(r'^(\d{1,2})$', text)
    if m:
        day = int(m.group(1))
        if 1 <= day <= 31:
            try:
                result = date(today.year, today.month, day)
                if result < today:
                    if today.month == 12:
                        result = date(today.year + 1, 1, day)
                    else:
                        result = date(today.year, today.month + 1, day)
                return result
            except:
                pass

        # "6дек" — день + месяц слитно
    m = re.match(r'^(\d{1,2})([а-яё]{3,})(?:\s*(\d{4}))?$', text)
    if m:
        day = int(m.group(1))
        month_name = m.group(2)
        year_str = m.group(3)
        months = {
            'января': 1, 'январь': 1, 'янв': 1,
            'февраля': 2, 'февраль': 2, 'фев': 2,
            'марта': 3, 'март': 3, 'мар': 3,
            'апреля': 4, 'апрель': 4, 'апр': 4,
            'мая': 5, 'май': 5,
            'июня': 6, 'июнь': 6, 'июн': 6,
            'июля': 7, 'июль': 7, 'июл': 7,
            'августа': 8, 'август': 8, 'авг': 8,
            'сентября': 9, 'сентябрь': 9, 'сен': 9, 'сент': 9,
            'октября': 10, 'октябрь': 10, 'окт': 10,
            'ноября': 11, 'ноябрь': 11, 'ноя': 11,
            'декабря': 12, 'декабрь': 12, 'дек': 12,
        }
        for name, num in months.items():
            if month_name.startswith(name) or name.startswith(month_name):
                year = int(year_str) if year_str else today.year
                try:
                    result = date(year, num, day)
                    if result < today and not year_str:
                        result = date(year + 1, num, day)
                    return result
                except:
                    pass

    # "20 9" — день месяц через пробел
    m = re.match(r'^(\d{1,2})\s+(\d{1,2})(?:\s+(\d{4}))?$', text)
    if m:
        day = int(m.group(1))
        month = int(m.group(2))
        year_str = m.group(3)
        if year_str:
            year = int(year_str)
        else:
            year = today.year
        try:
            result = date(year, month, day)
            if result < today and not year_str:
                result = date(year + 1, month, day)
            return result
        except:
            pass

    return None


async def auto_confirm_date(context: ContextTypes.DEFAULT_TYPE):
    """Автоподтверждение даты через 30 секунд"""
    job = context.job
    task_id = job.data['task_id']
    date = job.data['date']
    date_str = job.data['date_str']
    chat_id = job.data['chat_id']

    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE tasks SET deadline = ? WHERE id = ?", (date, task_id))
    conn.commit()
    # Получаем задачу
    c.execute("SELECT t.title, o.name as obj FROM tasks t LEFT JOIN objects o ON t.object_id = o.id WHERE t.id = ?", (task_id,))
    row = c.fetchone()
    conn.close()
    title = row['title'] if row else '?'
    obj = row['obj'] if row and row['obj'] else 'Без объекта'

    await context.bot.send_message(
        chat_id=chat_id,
        text=f"✅ {title}\n{obj}\nСрок: {date_str}"
    )


async def handle_confirm_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка подтверждения даты"""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data.startswith("confirmdate_yes_"):
        parts = data.split("_")
        task_id = int(parts[2])
        date = parts[3]
        conn = get_connection()
        c = conn.cursor()
        c.execute("UPDATE tasks SET deadline = ? WHERE id = ?", (date, task_id))
        conn.commit()
        conn.close()
        # Убиваем job, если был
        try:
            jobs = context.job_queue.get_jobs_by_name(f"confirm_{task_id}")
            for j in jobs:
                j.schedule_removal()
        except:
            pass
        conn = get_connection()
        c = conn.cursor()
        c.execute("SELECT t.title, o.name as obj FROM tasks t LEFT JOIN objects o ON t.object_id = o.id WHERE t.id = ?", (task_id,))
        row = c.fetchone()
        conn.close()
        title = row['title'] if row else '?'
        obj = row['obj'] if row and row['obj'] else 'Без объекта'
        await query.edit_message_text(f"✅ {title}\n{obj}\nСрок: {date}")
        return

    if data.startswith("confirmdate_no_"):
        parts = data.split("_")
        task_id = int(parts[2])
        # Убиваем job
        try:
            jobs = context.job_queue.get_jobs_by_name(f"confirm_{task_id}")
            for j in jobs:
                j.schedule_removal()
        except:
            pass
        await query.edit_message_text("❌ Отменено")
        return


async def handle_add_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка меню «➕ Добавить»"""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "menu_add":
        await query.edit_message_text(
            "➕ Что добавить?",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏗️ Новый объект", callback_data="add_object")],
                [InlineKeyboardButton("📋 Новая задача", callback_data="add_task")],
                [InlineKeyboardButton("💰 Расход", callback_data="add_expense")],
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")],
            ])
        )
        return

    if data == "add_object":
        context.user_data['waiting_for'] = 'new_object'
        await query.edit_message_text(
            "🏗️ Напиши название объекта:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Назад", callback_data="menu_add")]
            ])
        )
        return

    if data == "add_task":
        context.user_data['waiting_for'] = 'new_task'
        await query.edit_message_text(
            "📋 Выбери объект:",
            reply_markup=choose_object_for_task_keyboard()
        )
        return

    if data == "add_expense":
        context.user_data['waiting_for'] = 'new_expense'
        await query.edit_message_text(
            "💰 Выбери объект:",
            reply_markup=choose_object_for_expense_keyboard()
        )
        return

    if data.startswith("newtask_obj_"):
        object_id = int(data.replace("newtask_obj_", ""))
        obj = get_object(object_id)
        context.user_data['pending_task_object'] = obj
        context.user_data['waiting_for'] = 'new_task_text'
        await query.edit_message_text(
            f"📋 Новая задача в «{obj['name']}»\n\nНапиши задачу:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Назад", callback_data="add_task")]
            ])
        )
        return

    if data.startswith("newexp_obj_"):
        object_id = int(data.replace("newexp_obj_", ""))
        obj = get_object(object_id)
        context.user_data['pending_expense_object'] = obj
        context.user_data['waiting_for'] = 'new_expense_text'
        await query.edit_message_text(
            f"💰 Новый расход в «{obj['name']}»\n\nНапиши сумму и что купил:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Назад", callback_data="add_expense")]
            ])
        )
        return


def choose_object_for_task_keyboard():
    """Клавиатура выбора объекта для задачи"""
    objs = get_all_objects()
    buttons = []
    for o in objs:
        buttons.append([InlineKeyboardButton(
            f"🏗️ {o['name']}",
            callback_data=f"newtask_obj_{o['id']}"
        )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_add")])
    return InlineKeyboardMarkup(buttons)


def choose_object_for_expense_keyboard():
    """Клавиатура выбора объекта для расхода"""
    objs = get_all_objects()
    buttons = []
    for o in objs:
        buttons.append([InlineKeyboardButton(
            f"🏗️ {o['name']}",
            callback_data=f"newexp_obj_{o['id']}"
        )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_add")])
    return InlineKeyboardMarkup(buttons)




# === ЛИЧНЫЕ РАСХОДЫ ===

def format_personal_summary(period='month'):
    """Формирует текст сводки личных расходов"""
    from modules.personal import get_personal_summary
    data = get_personal_summary(period)
    period_names = {
        'today': 'сегодня',
        'week': 'за 7 дней',
        'month': 'за месяц',
        'all': 'за всё время'
    }
    text = f"💸 ЛИЧНЫЕ РАСХОДЫ ({period_names.get(period, period)})\n\n"
    text += f"Потрачено: {data['total']} ₽\n"
    text += f"Записей: {data['count']}\n\n"
    if data['by_category']:
        text += "📊 По категориям:\n"
        for item in data['by_category'][:10]:
            text += f"• {item['category']}: {item['amount']} ₽\n"
    else:
        text += "Пока нет записей за этот период."
    return text


def personal_keyboard():
    """Клавиатура для экрана личных расходов"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Добавить расход", callback_data="personal_add")],
        [InlineKeyboardButton("📅 За сегодня", callback_data="personal_today"),
         InlineKeyboardButton("📅 За неделю", callback_data="personal_week")],
        [InlineKeyboardButton("📅 За месяц", callback_data="personal_month"),
         InlineKeyboardButton("📅 За всё время", callback_data="personal_all")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")],
    ])


def choose_object_for_expense_keyboard_amount(amount):
    """Клавиатура выбора объекта для расхода с суммой (только объект, без категории)"""
    objs = get_all_objects()
    buttons = []
    for o in objs:
        buttons.append([InlineKeyboardButton(
            f"🏗️ {o['name']}",
            callback_data=f"objexp_obj_{amount}_{o['id']}"
        )])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="menu_back")])
    return InlineKeyboardMarkup(buttons)


# === OCR: распознавание чеков ===

async def handle_recognize_receipt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Скачивает фото и распознаёт через OCR.space."""
    query = update.callback_query
    await query.answer()

    pending = context.user_data.get('pending_photo') or {}
    file_id = pending.get('file_id')
    if not file_id:
        await query.edit_message_text("❌ Фото потерялось. Пришли заново.")
        return

    await query.edit_message_text("📷 Распознаю чек... (5-10 секунд)")

    try:
        from modules.ocr import ocr_image, parse_receipt
        # Скачиваем файл через Telegram API
        tg_file = await context.bot.get_file(file_id)
        import io
        buf = io.BytesIO()
        await tg_file.download_to_memory(buf)
        image_bytes = buf.getvalue()

        result = ocr_image(image_bytes)
        if not result.get('ok'):
            err = result.get('error', '')
            msg = "❌ Не смог распознать чек\n\n"
            msg += f"*Техническая ошибка:* {err}\n\n"
            msg += "📷 *Что попробовать:*\n"
            msg += "• Переснять при лучшем свете\n"
            msg += "• Отправить чек без тени\n"
            msg += "• Повторить через минуту (сервер может быть занят)\n"
            msg += "• Или добавить расход вручную через меню"
            await query.edit_message_text(
                msg,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Попробовать снова", callback_data="recognize_receipt")],
                    [InlineKeyboardButton("💰 Добавить вручную", callback_data="menu_add")],
                ]),
                parse_mode=ParseMode.MARKDOWN
            )
            return

        text = result.get('text', '')
        parsed = parse_receipt(text)
        parsed['items'] = []
        raw_items = []

        # ВАЛИДАЦИЯ: сохраняем позиции только если они "осмысленные"
        items = []
        amount = parsed.get('amount')
        if amount and raw_items:
            items_sum = sum(it.get('total', 0) for it in raw_items)
            # 1. Сумма должна сходиться (±10%)
            sum_ok = abs(items_sum - amount) / max(amount, 1) <= 0.1
            # 2. Все названия должны быть осмысленными (>= 3 букв, не стоп-слово)
            names_ok = all(
                sum(c.isalpha() for c in (it.get('name') or '')) >= 3
                for it in raw_items
            )
            # 3. Минимум 3 позиции
            count_ok = len(raw_items) >= 3
            if sum_ok and names_ok and count_ok:
                items = raw_items
        parsed['items'] = items

        # Формируем ответ
        msg = "💳 *Результат распознавания:*\n\n"
        if parsed['amount']:
            msg += f"💰 Сумма: {parsed['amount']} ₽\n"
        else:
            msg += "💰 Сумма: не найдена\n"
        if parsed['shop']:
            msg += f"🏪 Магазин: {parsed['shop']}\n"
        if parsed['date']:
            msg += f"📅 Дата: {parsed['date']}\n"
        msg += f"\n📄 *Сырой текст:*\n```\n{text[:800]}\n```"

        buttons = []
        if parsed['amount']:
            buttons.append([InlineKeyboardButton(
                f"💰 Записать расход {parsed['amount']} ₽",
                callback_data=f"receipt_save_{parsed['amount']}"
            )])
        buttons.append([InlineKeyboardButton("📸 Другое фото", callback_data="menu_back")])
        buttons.append([InlineKeyboardButton("🏠 Меню", callback_data="menu_back")])

        context.user_data['pending_receipt'] = parsed
        await query.edit_message_text(
            msg,
            reply_markup=InlineKeyboardMarkup(buttons),
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        await query.edit_message_text(
            f"❌ Ошибка распознавания: {e}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")]
            ])
        )


async def handle_receipt_save(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Сохраняет распознанный расход — спрашивает объект."""
    query = update.callback_query
    await query.answer()
    data = query.data  # receipt_save_<amount>
    amount = int(data.replace("receipt_save_", ""))

    # Выбор объекта
    objs = get_all_objects()
    if not objs:
        await query.edit_message_text("❌ Нет объектов. Создай сначала.")
        return

    buttons = []
    for o in objs[:20]:
        buttons.append([InlineKeyboardButton(
            f"🏗️ {o['name']}",
            callback_data=f"receipt_obj_{amount}_{o['id']}"
        )])
    buttons.append([InlineKeyboardButton("❌ Отмена", callback_data="menu_back")])

    await query.edit_message_text(
        f"💰 Расход {amount} ₽\n\nВыбери объект:",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def handle_receipt_object(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Создаёт расход в выбранном объекте."""
    query = update.callback_query
    await query.answer()
    data = query.data  # receipt_obj_<amount>_<obj_id>
    parts = data.replace("receipt_obj_", "").split("_")
    amount = int(parts[0])
    obj_id = int(parts[1])
    obj = get_object(obj_id)
    if not obj:
        await query.edit_message_text("❌ Объект не найден")
        return

    # Спрашиваем категорию
    context.user_data['pending_receipt_expense'] = {'amount': amount, 'obj_id': obj_id}
    await query.edit_message_text(
        f"💰 {amount} ₽ в «{obj['name']}»\n\nКатегория?",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🧱 Материалы", callback_data=f"receipt_cat_{amount}_{obj_id}_материалы")],
            [InlineKeyboardButton("🔧 Инструмент", callback_data=f"receipt_cat_{amount}_{obj_id}_инструмент")],
            [InlineKeyboardButton("🚕 Транспорт", callback_data=f"receipt_cat_{amount}_{obj_id}_транспорт")],
            [InlineKeyboardButton("🍔 Еда", callback_data=f"receipt_cat_{amount}_{obj_id}_еда")],
            [InlineKeyboardButton("📦 Прочее", callback_data=f"receipt_cat_{amount}_{obj_id}_прочее")],
            [InlineKeyboardButton("❌ Отмена", callback_data="menu_back")],
        ])
    )


async def handle_receipt_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Сохраняет расход с категорией + позиции чека в receipt_items."""
    query = update.callback_query
    await query.answer()
    data = query.data  # receipt_cat_<amount>_<obj_id>_<category>
    parts = data.replace("receipt_cat_", "").split("_", 2)
    amount = int(parts[0])
    obj_id = int(parts[1])
    category = parts[2] if len(parts) > 2 else 'прочее'
    obj = get_object(obj_id)

    # 1. Создаём расход в finance
    finance_id = add_expense(obj_id, amount, category)

    # 2. Сохраняем позиции чека
    receipt = context.user_data.get('pending_receipt') or {}
    items = receipt.get('items', [])
    shop = receipt.get('shop') or ''
    date = receipt.get('date')

    saved = 0
    if items:
        conn = get_connection()
        c = conn.cursor()
        for it in items:
            c.execute(
                "INSERT INTO receipt_items (finance_id, object_id, name, qty, price, total, is_personal, receipt_date, shop) "
                "VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)",
                (finance_id, obj_id, it.get('name'), it.get('qty'), it.get('price'), it.get('total'), date, shop)
            )
            saved += 1
        conn.commit()
        conn.close()

    # 3. Очищаем pending
    context.user_data['pending_receipt'] = None

    msg = f"✅ Расход {amount} ₽ ({category}) в «{obj['name']}» записан\n"
    if saved:
        msg += f"📋 Позиций чека: {saved}"
    if shop:
        msg += f"\n🏪 {shop}"

    await query.edit_message_text(
        msg,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📋 Позиции чека", callback_data=f"receipt_show_{finance_id}")],
            [InlineKeyboardButton("💰 К финансам", callback_data="menu_finance")],
            [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
        ])
    )


async def handle_receipt_show(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает позиции чека по finance_id."""
    query = update.callback_query
    await query.answer()
    fid = int(query.data.replace("receipt_show_", ""))

    conn = get_connection()
    c = conn.cursor()
    c.execute(
        "SELECT name, qty, price, total FROM receipt_items WHERE finance_id = ? ORDER BY id",
        (fid,)
    )
    rows = c.fetchall()
    conn.close()

    if not rows:
        await query.edit_message_text(
            "📋 Позиций нет",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")]
            ])
        )
        return

    text = f"📋 *Позиции чека #{fid}:*\n\n"
    total_sum = 0
    for r in rows:
        name = r['name'] or '—'
        qty = r['qty'] or 1
        price = r['price'] or 0
        total = r['total'] or 0
        text += f"• {name}\n"
        text += f"  {qty} × {int(price)} ₽ = {int(total)} ₽\n"
        total_sum += total

    text += f"\n💰 *Итого: {int(total_sum)} ₽*"

    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💰 К финансам", callback_data="menu_finance")],
            [InlineKeyboardButton("🏠 Меню", callback_data="menu_back")],
        ]),
        parse_mode=ParseMode.MARKDOWN
    )
