"""Точка сборки БО 7.7"""
import os
import logging
from telegram import BotCommand
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from config import TOKEN, validate_config, MAIN_ADMIN_TG_ID
from db import init_db
from handlers.onboarding import register_onboarding_handlers
from handlers.admin import register_admin_handlers
from handlers.commands import (
    handle_task_action, handle_add_menu, handle_confirm_date,
    handle_choose_object, handle_category,
    start, help_command, add_object_command, objects_command,
    add_task_command, tasks_command, done_command,
    finance_command, add_expense_command, personal_command, handle_callback, handle_text,
    handle_photo, handle_photo_stage, handle_photo_task, handle_photo_save,
    handle_skip_photo, photos_command, handle_document,
    handle_photo_filter, handle_photo_page,
    handle_recognize_receipt, handle_receipt_save, handle_receipt_object, handle_receipt_category, handle_receipt_show,
    clients_command, deals_command, handle_crm_menu
)
from handlers.digest_cmd import digest_now_command, survey_now_command
from interfaces.telegram.rooms import handle_rooms_callback
from modules.digest import send_morning_digest_with_log, send_evening_survey_with_log, catch_up_digests
from modules.backup_db import send_daily_backup, backup_now_command
from datetime import time
from zoneinfo import ZoneInfo

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
# Отключаем логи httpx/httpcore/telegram (чтобы токен не утекал в логи)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)
logging.getLogger("telegram.ext").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

async def error_handler(update, context):
    import traceback
    print("=" * 60, flush=True)
    print(f"❌ ERROR_HANDLER CALLED", flush=True)
    if update:
        try:
            print(f"   update type: {type(update).__name__}", flush=True)
            if hasattr(update, 'message') and update.message:
                print(f"   text: {update.message.text!r}", flush=True)
        except Exception:
            pass
    if context and context.error:
        print(f"   error: {context.error!r}", flush=True)
        print(f"   traceback:", flush=True)
        traceback.print_exception(type(context.error), context.error, context.error.__traceback__)
    print("=" * 60, flush=True)
    
    """Ловит ошибки. Сетевые — тихо логирует, остальные — отправляет админу."""
    err_name = type(context.error).__name__
    err_str = str(context.error)

    # Сетевые ошибки — не спамим, просто логируем
    network_errors = ("ReadError", "ConnectError", "TimeoutException",
                      "NetworkError", "WriteError", "ConnectTimeout",
                      "ReadTimeout", "PoolTimeout", "RemoteProtocolError")
    if any(n in err_name for n in network_errors):
        logger.warning(f"🌐 Сетевая ошибка (проигнорировано): {err_name}: {err_str}")
        return

    # Остальные — логируем и шлём админу
    logger.error(f"❌ Ошибка: {context.error}", exc_info=context.error)
    try:
        await context.bot.send_message(
            chat_id=MAIN_ADMIN_TG_ID,
            text=f"⚠️ Ошибка в боте:\n\n{err_name}: {err_str}"
        )
    except Exception:
        pass


def _ensure_netrc():
    """Автопочинка ~/.netrc при старте — если GITHUB_TOKEN есть, а .netrc нет."""
    try:
        token = os.getenv("GITHUB_TOKEN", "").strip()
        if not token:
            return
        netrc_path = os.path.expanduser("~/.netrc")
        need_write = True
        if os.path.exists(netrc_path):
            with open(netrc_path) as f:
                content = f.read()
            if token in content and "github.com" in content:
                need_write = False
        if need_write:
            with open(netrc_path, "w") as f:
                f.write(f"machine github.com\nlogin masterboplus-netizen\npassword {token}\n")
            os.chmod(netrc_path, 0o600)
            print("✅ ~/.netrc пересоздан")
    except Exception as e:
        print(f"⚠️ _ensure_netrc: {e}")


def main():
    _ensure_netrc()
    if not validate_config():
        return
    init_db()

    # === KEEP ALIVE (не даём Replit заснуть) ===
    import keep_alive
    keep_alive.start()
    # ===========================================

    app = Application.builder().token(TOKEN).build()
    # Настройка постоянного меню команд + дайджестов
    async def post_init(app):
        await app.bot.set_my_commands([
            BotCommand("start", "🏠 Главное меню"),
            BotCommand("objects", "🏗️ Объекты"),
            BotCommand("tasks", "📋 Задачи"),
            BotCommand("finance", "💰 Финансы"),
            BotCommand("clients", "👥 Клиенты"),
            BotCommand("deals", "💼 Сделки"),
            BotCommand("personal", "💸 Личные расходы"),
            BotCommand("photos", "📸 Фото объекта"),
            BotCommand("add", "➕ Добавить"),
            BotCommand("help", "⚙️ Помощь"),
        ])
        # Утренний дайджест — 9:00 МСК (6:00 UTC)
        app.job_queue.run_daily(
            send_morning_digest_with_log,
            time=time(hour=6, minute=0, tzinfo=ZoneInfo("UTC")),
            name="morning_digest"
        )
        # Вечерний опрос — 18:00 МСК (15:00 UTC)
        app.job_queue.run_daily(
            send_evening_survey_with_log,
            time=time(hour=15, minute=0, tzinfo=ZoneInfo("UTC")),
            name="evening_survey"
        )
        # Автобэкап БД — 23:00 МСК (20:00 UTC)
        app.job_queue.run_daily(
            send_daily_backup,
            time=time(hour=20, minute=0, tzinfo=ZoneInfo("UTC")),
            name="daily_backup"
        )
        logger.info("⏰ Дайджесты: 9:00 и 18:00 МСК, автобэкап БД: 23:00 МСК")

        # Догоняющий дайджест — если бот запущен после 9:00 / 18:00
        try:
            await catch_up_digests(app)
        except Exception as e:
            logger.error(f"⚠️ catch_up_digests: {e}")

    app.post_init = post_init

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("add_object", add_object_command))
    app.add_handler(CommandHandler("objects", objects_command))
    app.add_handler(CommandHandler("add", add_task_command))
    app.add_handler(CommandHandler("tasks", tasks_command))
    app.add_handler(CommandHandler("done", done_command))
    app.add_handler(CommandHandler("finance", finance_command))
    app.add_handler(CommandHandler("add_expense", add_expense_command))
    app.add_handler(CommandHandler("personal", personal_command))
    app.add_handler(CommandHandler("clients", clients_command))
    app.add_handler(CommandHandler("deals", deals_command))
    app.add_handler(CommandHandler("photos", photos_command))
    app.add_handler(CommandHandler("digest_now", digest_now_command))
    app.add_handler(CommandHandler("survey_now", survey_now_command))
    app.add_handler(CommandHandler("backup_now", backup_now_command))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    app.add_handler(CallbackQueryHandler(handle_crm_menu, pattern="^(menu_crm|crm_|unknown_|deal_|client_|activity_)"))
    app.add_handler(CallbackQueryHandler(handle_photo_page, pattern="^photopage_"))
    app.add_handler(CallbackQueryHandler(handle_photo_filter, pattern="^photofilt_"))
    app.add_handler(CallbackQueryHandler(handle_skip_photo, pattern="^skip_photo_"))
    app.add_handler(CallbackQueryHandler(handle_photo_stage, pattern="^photo_obj_"))
    app.add_handler(CallbackQueryHandler(handle_photo_task, pattern="^photo_stage_"))
    app.add_handler(CallbackQueryHandler(handle_photo_save, pattern="^photo_task_"))
    app.add_handler(CallbackQueryHandler(handle_category, pattern="^cat_"))
    app.add_handler(CallbackQueryHandler(handle_choose_object, pattern="^choose_obj_"))
    app.add_handler(CallbackQueryHandler(handle_confirm_date, pattern="^confirmdate_"))
    app.add_handler(CallbackQueryHandler(handle_add_menu, pattern="^(menu_add|add_object|add_task|add_expense|newtask_obj_|newexp_obj_)"))
    app.add_handler(CallbackQueryHandler(handle_task_action, pattern="^(task_|taskdone_|taskdel_|setdate_|taskdate_|tasknodate_|taskprio_|setprio_|taskrename_|taskassign_|setassigned_|setrange_|setduration_|cal_|dur_days_)"))
    register_onboarding_handlers(app)
    register_admin_handlers(app)
    app.add_handler(CallbackQueryHandler(handle_recognize_receipt, pattern="^recognize_receipt$"))
    app.add_handler(CallbackQueryHandler(handle_receipt_save, pattern="^receipt_save_"))
    app.add_handler(CallbackQueryHandler(handle_receipt_object, pattern="^receipt_obj_"))
    app.add_handler(CallbackQueryHandler(handle_receipt_category, pattern="^receipt_cat_"))
    app.add_handler(CallbackQueryHandler(handle_receipt_show, pattern="^receipt_show_"))
    app.add_handler(CallbackQueryHandler(handle_rooms_callback, pattern="^(rooms_list_|room_|wall_|openings_|opening_|comm_|obj_|floor_|group_|cables_|panels_|panel_|plumb_|works_|prices_)"))
    app.add_handler(CallbackQueryHandler(handle_callback, pattern="^(menu_crm|crm_|unknown_|deal_|client_|activity_)"))
    app.add_handler(CallbackQueryHandler(handle_callback, pattern="^(?!room_|rooms_|wall_|openings_|opening_|cat_|choose_obj_|task_|taskdone_|taskdel_|setdate_|taskdate_|taskprio_|setprio_|taskrename_|taskassign_|setassigned_|setrange_|setduration_|cal_|dur_days_|floor_|group_|obj_|comm_).*"))

    app.add_error_handler(error_handler)

    logger.info("🚀 БО 7.7 запущен! Все хендлеры зарегистрированы.")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()