"""core.measures — размеры комнат (обновлённый)."""
from core.db import fetchone, fetchall, commit


def add_measure(room_id, category, label=None, length=None, width=None,
                height=None, depth=None, angle=None, unit="см", note=None,
                tenant_id=1, created_by=None,
                wall_pos=None, angle_value=None, angle_method=None,
                angle_diagonal_cm=None, has_rounded=None, radius=None,
                rounded_corner=None,
                measured_bottom=None, measured_middle=None, measured_top=None,
                is_wavy=None, deviation_plus=None, deviation_minus=None,
                order_num=None, has_hidden=None, hidden_note=None,
                lean_angle=None, lean_direction=None,
                material=None, session_id=None,
                start_x=None, start_y=None, end_x=None, end_y=None,
                start_z=None, end_z=None, wavy_note=None,
                has_niche=None):
    """Добавляет размер. Возвращает measure_id."""
    return commit(
        """INSERT INTO room_measures
           (room_id, session_id, category, label, length, width, height, depth, angle,
            unit, note, tenant_id, created_by,
            wall_pos, angle_value, angle_method, angle_diagonal_cm,
            has_rounded, radius, rounded_corner,
            measured_bottom, measured_middle, measured_top,
            is_wavy, deviation_plus, deviation_minus,
            order_num, has_hidden, hidden_note, lean_angle, lean_direction,
            material,
            start_x, start_y, end_x, end_y, start_z, end_z,
            wavy_note)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (room_id, session_id, category, label, length, width, height, depth, angle,
         unit, note, tenant_id, created_by,
         wall_pos, angle_value, angle_method, angle_diagonal_cm,
         has_rounded, radius, rounded_corner,
         measured_bottom, measured_middle, measured_top,
         is_wavy, deviation_plus, deviation_minus,
         order_num, has_hidden, hidden_note, lean_angle, lean_direction,
         material,
         start_x, start_y, end_x, end_y, start_z, end_z,
         wavy_note)
    )


def get_measure(measure_id):
    row = fetchone("SELECT * FROM room_measures WHERE id = ?", (measure_id,))
    return dict(row) if row else None


def get_measures(room_id, category=None, session_id=None):
    conditions = ["room_id = ?"]
    params = [room_id]
    if category:
        conditions.append("category = ?")
        params.append(category)
    if session_id:
        conditions.append("session_id = ?")
        params.append(session_id)
    query = f"SELECT * FROM room_measures WHERE {' AND '.join(conditions)} ORDER BY category, id"
    rows = fetchall(query, tuple(params))
    return [dict(r) for r in rows]


def update_measure(measure_id, **kwargs):
    allowed = {"label", "length", "width", "height", "depth", "angle",
               "unit", "note", "category", "material"}
    fields, params = [], []
    for k, v in kwargs.items():
        if k in allowed:
            fields.append(f"{k} = ?")
            params.append(v)
    if not fields:
        return False
    params.append(measure_id)
    commit(f"UPDATE room_measures SET {', '.join(fields)} WHERE id = ?", params)
    return True


def delete_measure(measure_id):
    commit("DELETE FROM room_measures WHERE id = ?", (measure_id,))
    return True


def calculate_room_areas(room_id, session_id=None):
    """Считает площади (стены, пол, потолок) в м²."""
    measures = get_measures(room_id, session_id=session_id)
    room = None
    try:
        from core.rooms import get_room
        room = get_room(room_id)
    except Exception:
        pass
    room_height = (room.get('height') if room else None) or 0

    walls_total = 0.0
    floor_area = 0.0
    ceiling_area = 0.0
    openings_total = 0.0
    openings = []
    has_height = False

    for m in measures:
        L = m.get('length') or 0
        W = m.get('width') or 0
        H = m.get('height') or room_height or 0
        cat = m.get('category')

        if cat == 'wall':
            if H:
                has_height = True
            area = L * H if (L and H) else (W * H if (W and H) else 0)
            walls_total += area
        elif cat == 'floor':
            floor_area += L * W if (L and W) else 0
        elif cat == 'ceiling':
            ceiling_area += L * W if (L and W) else 0
        elif cat in ('window', 'door', 'opening'):
            area = L * H if (L and H) else (L * W if (L and W) else 0)
            openings_total += area
            openings.append({'label': m.get('label') or cat, 'area': round(area, 2)})

    if floor_area == 0:
        wall_measures = [m for m in measures if m.get('category') == 'wall']
        if len(wall_measures) >= 2:
            lengths = sorted([(m.get('length') or 0) for m in wall_measures], reverse=True)
            floor_area = lengths[0] * lengths[1]

    walls_net = max(walls_total - openings_total, 0)

    return {
        'walls_total': round(walls_total / 10000, 2) if has_height else None,
        'walls_net': round(walls_net / 10000, 2) if has_height else None,
        'floor': round(floor_area / 10000, 2),
        'ceiling': round(ceiling_area / 10000, 2),
        'openings_total': round(openings_total / 10000, 2),
        'openings': openings,
        'has_height': has_height,
    }


def get_walls_ordered(room_id, session_id=None):
    """Стены, отсортированные по wall_pos."""
    walls = get_measures(room_id, category='wall', session_id=session_id)
    pos_order = {'напротив': 1, 'слева': 2, 'у входа': 3, 'справа': 4}
    return sorted(walls, key=lambda w: pos_order.get(w.get('wall_pos') or '', 9))


def start_walls_round(room_id):
    from datetime import datetime
    commit("UPDATE rooms SET walls_started_at = ? WHERE id = ?",
           (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), room_id))


def complete_walls_round(room_id):
    from datetime import datetime
    commit("UPDATE rooms SET walls_completed_at = ? WHERE id = ?",
           (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), room_id))


def get_walls_progress(room_id):
    row = fetchone(
        "SELECT walls_started_at, walls_completed_at FROM rooms WHERE id = ?",
        (room_id,)
    )
    walls = get_walls_ordered(room_id)
    return {
        'walls_count': len(walls),
        'current_step': len(walls) + 1,
        'started_at': row['walls_started_at'] if row else None,
        'completed_at': row['walls_completed_at'] if row else None,
    }


def format_measure(m, show_area=False):
    cat_icons = {'wall': '🧱', 'floor': '📏', 'ceiling': '⬆️',
                 'window': '🪟', 'door': '🚪', 'opening': '🕳', 'corner': '📐'}
    icon = cat_icons.get(m.get('category'), '📏')
    label = m.get('label') or m.get('category')
    if label and label.startswith('Стена '):
        label = label[6:]

    def fmt(v):
        if v is None or v == 0:
            return None
        return str(int(v)) if v == int(v) else str(round(v, 1))

    L, W, H = m.get('length'), m.get('width'), m.get('height')
    parts = []
    if L: parts.append(fmt(L))
    if W: parts.append(fmt(W))
    if H: parts.append(fmt(H))
    dims = " × ".join(parts) if parts else "—"
    return f"{icon} {label}: {dims} см"


# === ОБЁРТКИ ДЛЯ СОВМЕСТИМОСТИ (перенесено в core.niches / core.openings) ===

# --- Ниши (core.niches) ---
def add_niche(*args, **kwargs):
    from core.niches import add_niche as _f
    return _f(*args, **kwargs)

def get_niches(*args, **kwargs):
    from core.niches import get_niches as _f
    return _f(*args, **kwargs)

def get_niches_by_room(*args, **kwargs):
    from core.niches import get_niches_by_room as _f
    return _f(*args, **kwargs)

def update_niche(*args, **kwargs):
    from core.niches import update_niche as _f
    return _f(*args, **kwargs)

def delete_niche(*args, **kwargs):
    from core.niches import delete_niche as _f
    return _f(*args, **kwargs)

def format_niche(*args, **kwargs):
    from core.niches import format_niche as _f
    return _f(*args, **kwargs)

# --- Проёмы (core.openings) ---
def add_opening(*args, **kwargs):
    from core.openings import add_opening as _f
    return _f(*args, **kwargs)

def get_opening(*args, **kwargs):
    from core.openings import get_opening as _f
    return _f(*args, **kwargs)

def get_openings(*args, **kwargs):
    from core.openings import get_openings as _f
    return _f(*args, **kwargs)

def get_openings_by_wall(*args, **kwargs):
    from core.openings import get_openings_by_wall as _f
    return _f(*args, **kwargs)

def update_opening(*args, **kwargs):
    from core.openings import update_opening as _f
    return _f(*args, **kwargs)

def delete_opening(*args, **kwargs):
    from core.openings import delete_opening as _f
    return _f(*args, **kwargs)

def format_opening(*args, **kwargs):
    from core.openings import format_opening as _f
    return _f(*args, **kwargs)

# --- OPENING_TYPES как константа ---
from core.openings import OPENING_TYPES  # noqa: E402
